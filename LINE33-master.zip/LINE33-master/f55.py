import LINE
from LINE import *
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from gtts import gTTS
from time import sleep
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
from googletrans import Translator
from humanfriendly import format_timespan, format_size, format_number, format_length
import time, random, sys, pafy, json, codecs, threading, glob, re, string, os, requests, six, ast, pytz, urllib, urllib3, urllib.parse, traceback, atexit, shutil
import youtube_dl

botStart = time.time()
mulai = time.time()
tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)
creator = ["u4d2f1c2fbee16358f12c749f406cfbf0"]
admin = ["u4d2f1c2fbee16358f12c749f406cfbf0"]

fino = LINE("EtrzfdvYKmx4ZbTplZX0.ts8Cl77Hy1JXlhsFqgZ78a.33g+grx4LM4/8E+IL6ZPcgPFcaeb04XSanBTRZM8ZAs=") 
fino1 = LINE("EtCJlZA5ZqJzmvEHmdFf.pB0BVWo2YSkUZCU3qzbRdW.xuxF98HNl/dKxfRml3/tSmSfvu10jDXWyxybB6ikw6k=")
fino2 = LINE("EtpbwTo2Hm4jCEKLmN0a.gjd41+zU09CjgGt3wnJxUG.QvwlXf4mVNkDBvVAc6c16/f+5hnZlMgHIuYMLR+bWtI=")
fino3 = LINE("Ethwco7fsKBIeyz1XWz3.b6vsK15WiU9rTmjncp4IqW.cMg27mhpCkz3v/x+P25dfA30XVT6vMwEbRbYFqP9pEw=")
fino4 = LINE("EtshVbq9PHCdm9P3VUXc.cX8pF62IZ+BXKnfSP9ifha.A720W07Zco3Pti9JbIQdnIGhXlKJBFownUnhUtqKjok=")
fino5 = LINE("EtjQJa16ov086rnvLf6e.6FfLs90vOVAoJZZfv3uVdG.ruBW5pDXFpPuIjFTqhkgudhdsDUM29fUc6IA4DTv7AY=")
fino10 = LINE("Et5vcd4bKZ0CBwcdsrl5.1xKs4keFGVWpEVMtqrXKHq.wHMFBJJKteySV6XrMZ8RN4pbYUZHeQbJVRlPuGhtM/k=")
sw1 = LINE("Etz7EzyJZgjEWyFA7GG6.weQGOL2TfzKiUDAuabRjPG.s9yj9pHM+I7e0OWUvch7P1R5gGcBcw6u5czyC2eAOy4=")

oepoll = OEPoll(fino) 

mid = fino.getProfile().mid
Amid = fino1.getProfile().mid
Bmid = fino2.getProfile().mid
Cmid = fino3.getProfile().mid
Dmid = fino4.getProfile().mid
Emid = fino5.getProfile().mid
Zmid = fino10.getProfile().mid
Kmid = sw1.getProfile().mid

KAC = [fino1,fino2,fino3,fino4,fino5]
Bots = [mid,Amid,Bmid,Cmid,Dmid,Emid,Zmid,Kmid]

Master = codecs.open("owner.json","r","utf-8")
owner = json.load(Master)
Master1 = codecs.open("admin.json","r","utf-8")
admsa = json.load(Master1) 
Master2 = codecs.open("staff.json","r","utf-8")
staff = json.load(Master2)
Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)
Thumb = codecs.open("prevent.json","r","utf-8")
Disc = json.load(Thumb)
Main = codecs.open("mybot.json","r","utf-8")
Run = json.load(Main)
stickersOpen = codecs.open("sticker.json","r","utf-8")
stickers = json.load(stickersOpen)

fino.profile = fino.talk.getProfile()
fino.groups = fino.talk.getGroupIdsJoined()
finoSettings = fino.getSettings()
fino1Settings = fino1.getSettings()
fino2Settings = fino2.getSettings()
fino3Settings = fino3.getSettings()
fino4Settings = fino4.getSettings()
fino5Settings = fino5.getSettings()
fino10Settings = fino10.getSettings()
sw1Settings = sw1.getSettings()

protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
protectcancel = []
welcome = []
msg_dict = {}

wait = {
    "finbot":True,
    "detectMention1":False,
}
cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

try:
    Run['mybot'] = {}
    Run["mybot"][mid] = True
    Run["mybot"][Amid] = True
    Run["mybot"][Bmid] = True
    Run["mybot"][Cmid] = True
    Run["mybot"][Dmid] = True
    Run["mybot"][Emid] = True
    Run["mybot"][Zmid] = True
    Run["mybot"][Kmid] = True
    backupData()
    print ("\n┅═ই۝FINBOT۝ईई═┅\nRunning...")
except:
    print ("\n┅═ই۝FINBOT۝ईई═┅\nRunning...")

def backupData():
    try:
        backup = owner
        f = codecs.open('owner.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = admsa
        f = codecs.open('admin.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = staff
        f = codecs.open('staff.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = Setmain
        f = codecs.open('setting.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = Disc
        f = codecs.open('prevent.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = stickers
        f = codecs.open('sticker.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = Run
        f = codecs.open('mybot.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False

def load():
    global stickers
    with open("sticker.json","r") as fp:
        stickers = json.load(fp)

def restart_program(): 
    print ("\nFINBOT-Restarted\nPlease Wait...")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)

def restartBot():
    print ("\nFINBOT-Restarting\nPlease Wait...")
    backupData() #Restart and backup data
    python = sys.executable
    os.execl(python, python, *sys.argv)
 
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def logError(text):
    fino.log("[ Error detected ] " + str(text))
    time_ = datetime.now()
    with open("errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
        
def mentionMembers(to, mid):
    try:
        arrData = ""
        textx = "[ Mention All Jumlah {} ]\n1. ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i.) " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(fino.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        fino10.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        fino10.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = "Hai...".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+Disc["mention"]
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(fino10.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        fino10.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        fino10.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = "환영합니다 ...  ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = fino.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+Disc["welcome"]+"\nGrup : "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(fino.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        fino.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        fino.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention(to, mid, firstmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x \n"
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        today = datetime.today()
        future = datetime(2018,3,1)
        hari = (str(future - today))
        comma = hari.find(",")
        hari = hari[:comma]
        teman = fino.getAllContactIds()
        gid = fino.getGroupIdsJoined()
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        eltime = time.time() - mulai
        bot = runtime(eltime)
        text += mention+"『 Jam 』  : "+datetime.strftime(timeNow,'%H:%M:%S')+" 『 Wib 』 \n『 Group 』  : "+str(len(gid))+"\n『 Friends 』  : "+str(len(teman))+"\n『 Expired 』  : In "+hari+"\n『 Version 』  : \n──┅═ই۝FINBOT۝ईई═┅──\n\n바람 부는 날 나는...\n너를 향해... \n연을 띄운다... \n마음을띄운다...\n티 없이 연연한\n너는\n문을 열고 나와...\n창공에..!\n휘날리는 깃발을 보아라.. \n연연한.. 오늘도 나는\n사랑의 실타래를 풀어.. \n절절한 사연을\n하늘 높이 띄운다\n 『 Date 』  : "+datetime.strftime(timeNow,'%Y-%m-%d')+"\n『 finbot Running 』  : \n • "+bot
        fino10.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        fino10.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMessageWithMention(to, mid):
    try:
        aa = '{"S":"0","E":"3","M":'+json.dumps(mid)+'}'
        text_ = '@x '
        fino10.sendMessage(to, text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
    except Exception as error:
        logError(error)
   
def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd

def helpMenu():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage = "╭─「 HELP 」──\n" + \
                  "│❂͜͡➣ Token menu\n" + \
                  "│❂͜͡➣ Help media\n" + \
                  "│❂͜͡➣ Help comm\n" + \
                  "╰───┅═ই۝FINBOT۝ईई═┅───\n"
    return helpMessage
def helpMedia():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage2 = "╭─「 MEDIA 」──\n" + \
                  "│❂͜͡➣ musik: ✖[link replace]\n" + \
                  "│❂͜͡➣ lirik: ✖[link replace]\n" + \
                  "│❂͜͡➣ ytmp4: \n" + \
                  "│❂͜͡➣ ytmp3: \n" + \
                  "│❂͜͡➣ cuaca: \n" + \
                  "│❂͜͡➣ sholat: \n" + \
                  "│❂͜͡➣ lokasi: \n" + \
                  "│❂͜͡➣ checkdate: \n" + \
                  "│❂͜͡➣ ig: \n" + \
                  "│❂͜͡➣ image: \n" + \
                  "│❂͜͡➣ imagetext: \n" + \
                  "│❂͜͡➣ ssweb: \n" + \
                  "│❂͜͡➣ ssig: \n" + \
                  "│❂͜͡➣ meme: \n" + \
                  "╰───┅═ই۝FINBOT۝ईई═┅───\n"
    return helpMessage2
def helpComm():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage3 = "╭─「 Help Command 」──\n" + \
                  "│❂͜͡➣ me\n" + \
                  "│❂͜͡➣ mybot\n" + \
                  "│❂͜͡➣ cfoto\n" + \
                  "│❂͜͡➣ cfotogroup\n" + \
                  "│❂͜͡➣ about\n" + \
                  "│❂͜͡➣ restart\n" + \
                  "│❂͜͡➣ runtime\n" + \
                  "│❂͜͡➣ time\n" + \
                  "│❂͜͡➣ group\n" + \
                  "│❂͜͡➣ Protectall 「 on/off 」\n" + \
                  "│❂͜͡➣ Protect 「 on/off 」\n" + \
                  "│❂͜͡➣ ProQr 「 on/off 」\n" + \
                  "│❂͜͡➣ ProJoin 「 on/off 」\n" + \
                  "│❂͜͡➣ Promem 「 on/off 」\n" + \
                  "│❂͜͡➣ ginfo\n" + \
                  "│❂͜͡➣ group [No group]\n" + \
                  "│❂͜͡➣ member [No member\n" + \
                  "│❂͜͡➣ open/close\n" + \
                  "│❂͜͡➣ addsticker 「 Query 」\n" + \
                  "│❂͜͡➣ dellsticker 「 Query 」\n" + \
                  "│❂͜͡➣ list sticker\n" + \
                  "│❂͜͡➣ @join\n" + \
                  "│❂͜͡➣ @bye\n" + \
                  "│❂͜͡➣ @login\n" + \
                  "│❂͜͡➣ @logout\n" + \
                  "│❂͜͡➣ auto add 「 on/off 」\n" + \
                  "│❂͜͡➣ auto leave 「 on/off 」\n" + \
                  "│❂͜͡➣ auto share 「 on/off 」\n" + \
                  "│❂͜͡➣ auto join 「 on/off 」\n" + \
                  "│❂͜͡➣ auto respon 「 on/off 」\n" + \
                  "│❂͜͡➣ sticker 「 on/off 」\n" + \
                  "│❂͜͡➣ contact 「 on/off 」\n" + \
                  "│❂͜͡➣ lurking 「 on/off 」\n" + \
                  "│❂͜͡➣ lukers 「 on/off 」\n" + \
                  "│❂͜͡➣ sider 「 on/off 」\n" + \
                  "│❂͜͡➣ welcome 「 on/off 」\n" + \
                  "│❂͜͡➣ banned add 「 on/off 」\n" + \
                  "│❂͜͡➣ banned dell 「 on/off 」\n" + \
                  "│❂͜͡➣ banned add 「 mention 」\n" + \
                  "│❂͜͡➣ banned dell 「 mention 」\n" + \
                  "╰───┅═ই۝FINBOT۝ईई═┅───\n"
    return helpMessage3
def helpbot():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage4 = "╭─『 Menu Token 』 ──\n" + \
                   "│❂͜͡➣ token mac\n" + \
                   "│❂͜͡➣ token win10\n" + \
                   "│❂͜͡➣token ios\n" + \
                   "│❂͜͡➣ token done [jika selsai login]\n" + \
                   "╰──┅═ই۝FINBOT۝ईई═┅── \n"
    return helpMessage4
def helpMeme():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage5 = "─❂『 Menu Meme 』 ❂─\n\n" + \
                   "❂͜͡➣ tenguy\n" + \
                   "❂͜͡➣ afraid\n" + \
                   "❂͜͡➣ older\n" + \
                   "❂͜͡➣ aag \n" + \
                   "❂͜͡➣ tried \n" + \
                   "❂͜͡➣ biw \n" + \
                   "❂͜͡➣ stew \n" + \
                   "❂͜͡➣ blb \n" + \
                   "❂͜͡➣ kermit \n" + \
                   "❂͜͡➣ bd \n" + \
                   "❂͜͡➣ ch \n" + \
                   "❂͜͡➣ cbg \n" + \
                   "❂͜͡➣ wonka \n" + \
                   "❂͜͡➣ cb \n" + \
                   "❂͜͡➣ keanu \n" + \
                   "❂͜͡➣ dsm \n" + \
                   "❂͜͡➣ live \n" + \
                   "❂͜͡➣ ants \n" + \
                   "❂͜͡➣ doge \n" + \
                   "❂͜͡➣ drake \n" + \
                   "❂͜͡➣ ermg \n" + \
                   "❂͜͡➣ facepalm \n" + \
                   "❂͜͡➣ firsttry \n" + \
                   "❂͜͡➣ fwp \n" + \
                   "❂͜͡➣ fa \n" + \
                   "❂͜͡➣ fbf \n" + \
                   "❂͜͡➣ fmr \n" + \
                   "❂͜͡➣ fry \n" + \
                   "❂͜͡➣ ggg \n" + \
                   "❂͜͡➣ hipster \n" + \
                   "❂͜͡➣ icanhas \n" + \
                   "❂͜͡➣ sparta\n" + \
                   "❂͜͡➣ whatyear\n" + \
                   "❂͜͡➣ center\n" + \
                   "❂͜͡➣ winter\n" + \
                   "❂͜͡➣ xy\n" + \
                   "❂͜͡➣ buzz\n" + \
                   "❂͜͡➣ yodawg\n" + \
                   "❂͜͡➣ yuno\n" + \
                   "❂͜͡➣ yallgot\n" + \
                   "❂͜͡➣ bad\n" + \
                   "❂͜͡➣ elf\n" + \
                   "❂͜͡➣ For ex⇢Meme [memelist]\n" + \
                   "\n❂͜͡➣ 『 ┅═ই۝FINBOT۝ईई═┅』 ❂͜͡➣\n"
    return helpMessage5
    
def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
        if op.type == 11:
            if op.param1 in protectqr:
                try:
                    if fino.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in admin:
                            fino.reissueGroupTicket(op.param1)
                            X = fino.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            fino.updateGroup(X)
                            fino.sendMessage(op.param1, None, contentMetadata={'mid': op.param2}, contentType=13)
                            Disc["blacklist"][op.param2] = True
                            with open('prevent.json', 'w') as fp:
                            	json.dump(prevent, fp, sort_keys=True, indent=4)
                except:
                    pass

        if op.type == 13:
            if mid in op.param3:
                if Disc["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in admin:
                        fino.acceptGroupInvitation(op.param1)
                        ginfo = fino.getGroup(op.param1)
                        fino.sendMessage(op.param1,"وَالسَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ" +str(ginfo.name))
                        fino.leaveGroup(op.param1)
                    else:
                        fino.acceptGroupInvitation(op.param1)
                        ginfo = fino.getGroup(op.param1)
                        fino.sendMessage(op.param1,"وَالسَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ" + str(ginfo.name))
        if op.type == 13:
            if mid in op.param3:
                if Disc["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in admin:
                        fino.acceptGroupInvitation(op.param1)
                        fino.inviteIntoGroup(op.param1,[Zmid])
                        fino10.acceptGroupInvitation(op.param1)
                        fino10.sendMessage(msg.to,"thanks for add me")
                    else:
                        fino.acceptGroupInvitation(op.param1)                     
  
        if op.type == 13:
            if op.param1 in protectinvite:
                if op.param2 not in Bots and op.param2 not in admin:
                    try:
                        group = fino10.getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _mid in gMembMids:

                                 fino10.cancelGroupInvitation(op.param1,[_mid])
                    except:
                        pass
 
        if op.type == 13:
            if op.param2 in Disc["blacklist"]:
                print ("Blacklist")
                if op.param2 not in Bots and op.param2 not in admin:
                    try:
                        #random.choice(KIC).cancelGroupInvitation(op.param1,[op.param3])
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            #ki.cancelGroupInvitation(op.param1,[op.param3])
                            fino1.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                #kk.cancelGroupInvitation(op.param1,[op.param3])
                                fino2.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    #kc.cancelGroupInvitation(op.param1,[op.param3])
                                    fino3.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    try:
                                        #ks.cancelGroupInvitation(op.param1,[op.param3])
                                        fino4.kickoutFromGroup(op.param1,[op.param2])        
                                    except:
                                        try:
                                            #ka.cancelGroupInvitation(op.param1,[op.param3])
                                            fino5.kickoutFromGroup(op.param1,[op.param2])           
                                        except:
                                            fino10.cancelGroupInvitation(op.param1,[op.param3])
  
        if op.type == 17:
            if op.param2 in Disc["blacklist"]:
                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

        if op.type == 17:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                ginfo = fino.getGroup(op.param1)
                contact = fino.getContact(op.param2).picturePath
                image = 'http://dl.profile.line.naver.jp'+contact
                welcomeMembers(op.param1, [op.param2])
                fino.sendImageWithURL(op.param1, image)

        if op.type == 17:
            if op.param1 in protectjoin:
                if op.param2 not in Bots and op.param2 not in admin:
                    Disc["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in Disc["blacklist"]:
                        	random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        
                    except:
                        pass

        if op.type == 0:
            return
        if op.type == 5:
            if Disc["autoAdd"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    if (Disc["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        fino10.sendMessage(op.param1, Disc["message"])
                        fino1.sendMessage(op.param1, Disc["message"])
                        fino2.sendMessage(op.param1, Disc["message"])
                        fino3.sendMessage(op.param1, Disc["message"])
                        fino4.sendMessage(op.param1, Disc["message"])
                        fino5.sendMessage(op.param1, Disc["message"])
#                        fino6.sendMessage(op.param1, Disc["message"])
#                        fino7.sendMessage(op.param1, Disc["message"])
#                        fino8.sendMessage(op.param1, Disc["message"])
#                        fino9.sendMessage(op.param1, Disc["message"])
        if op.type == 19:
            if op.param1 in protectkick:
                if op.param2 not in Bots or admin:
                    Disc["blacklist"][op.param2] = True
                    random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                else:
                    pass
        if op.type == 32:
            if op.param1 in protectcancel:
                if op.param2 not in Bots or admin:
                    Disc["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in Disc["blacklist"]:
                            fino1.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
        if op.type == 19:
            if mid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    Disc["blacklist"][op.param2] = True
                    try:
                        fino1.inviteIntoGroup(op.param1,[op.param3])
                        fino.acceptGroupInvitation(op.param1)
                        fino1.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            fino2.inviteIntoGroup(op.param1,[op.param3])
                            fino.acceptGroupInvitation(op.param1)
                            fino2.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                fino3.inviteIntoGroup(op.param1,[op.param3])
                                fino.acceptGroupInvitation(op.param1)
                                fino3.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    G = fino10.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    fino1.kickoutFromGroup(op.param1,[op.param2])
                                    fino10.updateGroup(G)
                                    Ticket = fino10.reissueGroupTicket(op.param1)
                                    fino.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino5.acceptGroupInvitationByTicket(op.param1,Ticket) 
                                    fino10.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    sw1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = fino8.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    fino8.updateGroup(G)
                                    Ticket = fino8.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        fino1.inviteIntoGroup(op.param1,[op.param3])
                                        fino.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            fino2.kickoutFromGroup(op.param1,[op.param2])
                                            fino2.inviteIntoGroup(op.param1,[op.param3])
                                            fino.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
                return
            if Amid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    Disc["blacklist"][op.param2] = True
                    try:
                        fino2.kickoutFromGroup(op.param1,[op.param2])
                        fino3.inviteIntoGroup(op.param1,[op.param3])
                        fino1.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            fino3.kickoutFromGroup(op.param1,[op.param2])
                            fino4.inviteIntoGroup(op.param1,[op.param3])
                            fino1.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                fino4.kickoutFromGroup(op.param1,[op.param2])
                                fino5.inviteIntoGroup(op.param1,[op.param3])
                                fino1.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = fino10.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    fino2.kickoutFromGroup(op.param1,[op.param2])
                                    fino10.updateGroup(G)
                                    Ticket = fino10.reissueGroupTicket(op.param1)
                                    fino.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino5.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino10.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = fino2.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    fino2.updateGroup(G)
                                    Ticket = fino2.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        fino2.kickoutFromGroup(op.param1,[op.param2])
                                        fino2.inviteIntoGroup(op.param1,[op.param3])
                                        fino1.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            fino3.kickoutFromGroup(op.param1,[op.param2])
                                            fino3.inviteIntoGroup(op.param1,[op.param3])
                                            fino1.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
                return
            if Bmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    Disc["blacklist"][op.param2] = True
                    try:
                        fino3.kickoutFromGroup(op.param1,[op.param2])
                        fino4.inviteIntoGroup(op.param1,[op.param3])
                        fino2.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            fino4.kickoutFromGroup(op.param1,[op.param2])
                            fino5.inviteIntoGroup(op.param1,[op.param3])
                            fino2.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                fino5.kickoutFromGroup(op.param1,[op.param2])
                                fino10.inviteIntoGroup(op.param1,[op.param3])
                                fino2.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = fino.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    fino3.kickoutFromGroup(op.param1,[op.param2])
                                    fino.updateGroup(G)
                                    Ticket = fino.reissueGroupTicket(op.param1)
                                    fino.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino5.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino10.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = fino3.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    fino3.updateGroup(G)
                                    Ticket = fino3.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        fino4.kickoutFromGroup(op.param1,[op.param2])
                                        fino4.inviteIntoGroup(op.param1,[op.param3])
                                        fino2.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            fino5.kickoutFromGroup(op.param1,[op.param2])
                                            fino5.inviteIntoGroup(op.param1,[op.param3])
                                            fino2.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
                return
            if Cmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    Disc["blacklist"][op.param2] = True
                    try:
                        fino4.kickoutFromGroup(op.param1,[op.param2])
                        fino10.inviteIntoGroup(op.param1,[op.param3])
                        fino3.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            fino5.kickoutFromGroup(op.param1,[op.param2])
                            fino.inviteIntoGroup(op.param1,[op.param3])
                            fino3.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                fino1.kickoutFromGroup(op.param1,[op.param2])
                                fino2.inviteIntoGroup(op.param1,[op.param3])
                                fino3.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = fino10.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    fino4.kickoutFromGroup(op.param1,[op.param2])
                                    fino10.updateGroup(G)
                                    Ticket = fino10.reissueGroupTicket(op.param1)
                                    fino.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino5.acceptGroupInvitationByTicket(op.param1,Ticket) 
                                    fino10.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    sw1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = fino.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    fino.updateGroup(G)
                                    Ticket = fino.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        fino4.kickoutFromGroup(op.param1,[op.param2])
                                        fino10.inviteIntoGroup(op.param1,[op.param3])
                                        fino3.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            fino1.kickoutFromGroup(op.param1,[op.param2])
                                            fino.inviteIntoGroup(op.param1,[op.param3])
                                            fino3.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
                return
            if Dmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    Disc["blacklist"][op.param2] = True
                    try:
                        fino5.kickoutFromGroup(op.param1,[op.param2])
                        fino.inviteIntoGroup(op.param1,[op.param3])
                        fino4.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            fino1.kickoutFromGroup(op.param1,[op.param2])
                            fino10.inviteIntoGroup(op.param1,[op.param3])
                            fino4.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                fino2.kickoutFromGroup(op.param1,[op.param2])
                                fino3.inviteIntoGroup(op.param1,[op.param3])
                                fino4.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = fino.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    fino5.kickoutFromGroup(op.param1,[op.param2])
                                    fino.updateGroup(G)
                                    Ticket = fino.reissueGroupTicket(op.param1)
                                    fino.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino5.acceptGroupInvitationByTicket(op.param1,Ticket) 
                                    fino10.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    sw1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = fino.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    fino.updateGroup(G)
                                    Ticket = fino.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        fino4.kickoutFromGroup(op.param1,[op.param2])
                                        fino10.inviteIntoGroup(op.param1,[op.param3])
                                        fino3.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            fino1.kickoutFromGroup(op.param1,[op.param2])
                                            fino.inviteIntoGroup(op.param1,[op.param3])
                                            fino3.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
                return
            if Emid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    Disc["blacklist"][op.param2] = True
                    try:
                        fino1.kickoutFromGroup(op.param1,[op.param2])
                        fino2.inviteIntoGroup(op.param1,[op.param3])
                        fino5.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            fino2.kickoutFromGroup(op.param1,[op.param2])
                            fino10.inviteIntoGroup(op.param1,[op.param3])
                            fino5.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                fino3.kickoutFromGroup(op.param1,[op.param2])
                                fino.inviteIntoGroup(op.param1,[op.param3])
                                fino5.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = fino.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    fino3.kickoutFromGroup(op.param1,[op.param2])
                                    fino.updateGroup(G)
                                    Ticket = fino.reissueGroupTicket(op.param1)
                                    fino.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    fino5.acceptGroupInvitationByTicket(op.param1,Ticket) 
                                    fino10.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    sw1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = fino.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    fino.updateGroup(G)
                                    Ticket = fino.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        fino4.kickoutFromGroup(op.param1,[op.param2])
                                        fino10.inviteIntoGroup(op.param1,[op.param3])
                                        fino3.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            fino1.kickoutFromGroup(op.param1,[op.param2])
                                            fino1.inviteIntoGroup(op.param1,[op.param3])
                                            fino3.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
                return

            if Zmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    Disc["blacklist"][op.param2] = True
                    try:
                        fino4.inviteIntoGroup(op.param1,[op.param3])
                        fino10.acceptGroupInvitation(op.param1)
                        fino4.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            fino5.inviteIntoGroup(op.param1,[op.param3])
                            fino10.acceptGroupInvitation(op.param1)
                            fino5.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                fino3.kickoutFromGroup(op.param1,[op.param2])
                                fino3.inviteIntoGroup(op.param1,[op.param3])
                                fino10.acceptGroupInvitation(op.param1)
                            except:
                                pass

                return

        if op.type == 26:
           if wait["finbot"] == True:
               msg = op.message
               if msg._from not in Bots:
                 if Disc["talkban"] == True:
                   if msg._from in Disc["Talkblacklist"]:
                      try:
                          random.choice(KAC).kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              random.choice(KAC).kickoutFromGroup(msg.to, [msg._from])
                          except:
                              random.choice(KAC).kickoutFromGroup(msg.to, [msg._from])

               if msg.contentType == 7:
                 if Disc["sticker"] == True:
                    msg.contentType = 0
                    fino10.sendMessage(msg.to,"┌───[ Cek Sticker ID ]───\n︱STKID : " + msg.contentMetadata["STKID"] + "\n︱STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n︱STKVER : " + msg.contentMetadata["STKVER"]+ "\n︱Link Sticker" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if Disc["contact"] == True:
                    msg.contentType = 0
                    fino10.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = fino10.getContact(msg.contentMetadata["mid"])
                        path = fino10.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        fino10.sendMessage(msg.to,"♐ Nama : " + msg.contentMetadata["displayName"] + "\n♐ MID : " + msg.contentMetadata["mid"] + "\n♐ Status Msg : " + contact.statusMessage + "\n♐ Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        fino10.sendImageWithURL(msg.to, image)
               if 'MENTION' in msg.contentMetadata.keys()!= None:
                 if Disc["detectMention"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           fino10.sendMessage(msg.to, Disc["Respontag"])
                           fino10.sendMessage(msg.to, None, contentMetadata={"STKID":"7839705","STKPKGID":"1192862","STKVER":"1"}, contentType=7)
                           break
               if 'MENTION' in msg.contentMetadata.keys()!= None:
                 if wait["detectMention1"] == True:
                   balas1 = "Ini Foto Sii tukang Tag. . ."
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           fino.sendMessage(msg.to,Disc["Respontag1"])
                           fino.sendMessage(msg.to,balas1)
                           fino.sendImageWithURL(msg.to,image)
                           msg.contentType = 7
                           msg.text = None
                           msg.contentMetadata = {"STKID": "14220191","STKPKGID": "1359234","STKVER": "1" }
                           fino.sendMessage(msg)
                           break
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if Disc["Mentionkick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           fino10.mentiontag(msg.to,[msg._from])
                           fino10.sendMessage(msg.to, "Dont tag me....")
                           fino2.kickoutFromGroup(msg.to, [msg._from])
                           break
        if op.type == 25:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if Disc["sticker"] == True:
                    msg.contentType = 0
                    fino10.sendMessage(msg.to,"┌───[ Cek Sticker ID ]───\n︱STKID : " + msg.contentMetadata["STKID"] + "\n︱STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n︱STKVER : " + msg.contentMetadata["STKVER"]+ "\n︱Link Sticker" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 7:
                 if msg._from in admin:
                    if Disc["Addsticker"]["status"] == True:
                        stickers[Disc["Addsticker"]["name"]] = {"STKID":msg.contentMetadata["STKID"],"STKPKGID":msg.contentMetadata["STKPKGID"]}
                        f = codecs.open("sticker.json","w","utf-8")
                        json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                        fino10.sendMessage(msg.to, "Succes added to sticker to disc {}".format(str(Disc["Addsticker"]["name"])))
                        Disc["Addsticker"]["status"] = False
                        Disc["Addsticker"]["name"] = ""
               if msg.contentType == 13:
                 if Disc["contact"] == True:
                    msg.contentType = 0
                    fino10.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = fino10.getContact(msg.contentMetadata["mid"])
                        path = fino10.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        fino10.sendMessage(msg.to,"♐ Nama : " + msg.contentMetadata["displayName"] + "\n♐ MID : " + msg.contentMetadata["mid"] + "\n♐ Status Msg : " + contact.statusMessage + "\n♐ Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        fino10.sendImageWithURL(msg.to, image)
                 if msg._from in admin:
                  if Disc["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in Disc["blacklist"]:
                        fino10.sendMessage(msg.to,"Contact itu sudah ada di blacklist")
                        Disc["wblacklist"] = True
                    else:
                        Disc["blacklist"][msg.contentMetadata["mid"]] = True
                        Disc["wblacklist"] = True
                        fino10.sendMessage(msg.to,"Berhasil menambahkan ke blacklist user")
                  if Disc["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in Disc["blacklist"]:
                        del Disc["blacklist"][msg.contentMetadata["mid"]]
                        fino10.sendMessage(msg.to,"Berhasil menghapus dari blacklist user")
                    else:
                        Disc["dblacklist"] = True
                        fino10.sendMessage(msg.to,"Contact itu tidak ada di blacklist")

                 if msg._from in admin:
                  if Disc["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in Disc["Talkblacklist"]:
                        fino10.sendMessage(msg.to,"Contact itu sudah ada di Talkban")
                        Disc["Talkwblacklist"] = True
                    else:
                        Disc["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        Disc["Talkwblacklist"] = True
                        fino10.sendMessage(msg.to,"Berhasil menambahkan ke Talkban user")
                  if Disc["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in Disc["Talkblacklist"]:
                        del Disc["Talkblacklist"][msg.contentMetadata["mid"]]
                        fino10.sendMessage(msg.to,"Berhasil menghapus dari Talkban user")
                    else:
                        Disc["Talkdblacklist"] = True
                        fino10.sendMessage(msg.to,"Contact itu tidak ada di Talkban")

               if msg.contentType == 1:
                 if msg._from in admin:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = fino.server.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            fino10.sendMessage(msg.to, "Add image success")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False
               if msg.contentType == 1:
                   if msg._from in admin:
                       if mid in Setmain["foto"]:
                            path = fino.downloadObjectMsg(msg.id)
                            del Setmain["foto"][mid]
                            fino.updateProfilePicture(path)
                            fino.sendMessage(msg.to,"photo profile updated")
               if msg.contentType == 1:
                 if msg._from in admin:
                        if Amid in Setmain["foto"]:
                            path = fino1.downloadObjectMsg(msg.id)
                            del Setmain["foto"][Amid]
                            fino1.updateProfilePicture(path)
                            fino1.sendMessage(msg.to,"photo profile updated") 
               if msg.contentType == 1:
                 if msg._from in admin:
                        if Bmid in Setmain["foto"]:
                            path = fino2.downloadObjectMsg(msg.id)
                            del Setmain["foto"][Bmid]
                            fino2.updateProfilePicture(path)
                            fino2.sendMessage(msg.to,"photo profile updated")
               if msg.contentType == 1:
                 if msg._from in admin:
                        if Cmid in Setmain["foto"]: 
                            path = fino3.downloadObjectMsg(msg.id)
                            del Setmain["foto"][Cmid]
                            fino3.updateProfilePicture(path)
                            fino3.sendMessage(msg.to,"photo profile updated")
               if msg.contentType == 1:
                 if msg._from in admin:
                        if Dmid in Setmain["foto"]:
                            path = fino4.downloadObjectMsg(msg_id)
                            del Setmain["foto"][Dmid]
                            fino4.updateProfilePicture(path)
                            fino4.sendMessage(msg.to,"photo profile updated")
               if msg.contentType == 1:
                 if msg._from in admin:
                        if Emid in Setmain["foto"]:
                            path = fino5.downloadObjectMsg(msg_id)
                            del Setmain["foto"][Emid]
                            fino5.updateProfilePicture(path)
                            fino5.sendMessage(msg.to,"photo profile updated")
               if msg.contentType == 1:
                 if msg._from in admin:
                        if Zmid in Setmain["foto"]:
                            path = fino10.downloadObjectMsg(msg_id)
                            del Setmain["foto"][Zmid]
                            fino10.updateProfilePicture(path)
                            fino10.sendMessage(msg.to,"photo profile updated")
               if msg.contentType == 1:
                 if msg._from in admin:
                   if Setmain["changePicture"] == True:
                     path1 = fino1.downloadObjectMsg(msg_id)
                     path2 = fino2.downloadObjectMsg(msg_id)
                     path3 = fino3.downloadObjectMsg(msg_id)
                     path4 = fino4.downloadObjectMsg(msg_id)
                     path5 = fino5.downloadObjectMsg(msg_id)
                     path10 = fino10.downloadObjectMsg(msg_id)
                     Setmain["changePicture"] = False
                     fino1.updateProfilePicture(path1)
                     fino1.sendMessage(msg.to, "Profile Updated")
                     fino2.updateProfilePicture(path2)
                     fino2.sendMessage(msg.to, "Profile Updated")
                     fino3.updateProfilePicture(path3)
                     fino3.sendMessage(msg.to, "Profile Updated")
                     fino4.updateProfilePicture(path4)
                     fino4.sendMessage(msg.to, "Profile Updated")
                     fino5.updateProfilePicture(path5)
                     fino5.sendMessage(msg.to, "Profile Updated")
                     fino10.updateProfilePicture(path10)
                     fino10.sendMessage(msg.to, "Profile Updated")
                     
               if msg.toType == 2:
                 if msg._from in admin:
                   if Setmain["groupPicture"] == True:
                     path = fino10.downloadObjectMsg(msg_id)
                     Setmain["groupPicture"] = False
                     fino10.updateGroupPicture(msg.to, path)
                     fino10.sendMessage(msg.to, "Group profile updated")
               if msg.contentType == 0:
                    if Setmain["AutoRead"] == True:
                        fino.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                           for sticker in stickers:
                            if msg._from in admin:
                              if text.lower() == sticker:
                                  sid = stickers[text.lower()]["STKID"]
                                  spkg = stickers[text.lower()]["STKPKGID"]
                                  fino10.sendSticker(to, spkg, sid)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "help":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               helpMessage = helpMenu()
                               fino10.sendMessage(msg.to, str(helpMessage))
                        elif cmd == "help media":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               helpMessage2 = helpMedia()
                               fino10.sendMessage(msg.to, str(helpMessage2))
                        elif cmd == "help comm":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               helpMessage3 = helpComm()
                               fino10.sendMessage(msg.to, str(helpMessage3))
                        elif cmd == "token menu":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               helpMessage4 = helpbot()
                               fino10.sendMessage(msg.to, str(helpMessage4))
                        elif cmd == "meme menu":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               helpMessage5 = helpMeme()
                               fino10.sendMessage(msg.to, str(helpMessage5))
                        if cmd == "@login":
                            if msg._from in admin:
                                wait["finbot"] = True
                                fino10.sendMessage(msg.to, "Finbot@Relogin")
                        elif cmd == "@logout":
                            if msg._from in admin:
                                wait["finbot"] = False
                                fino10.sendMessage(msg.to, "Finbot@logout")
                                            
                        elif cmd == "status":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "╭─「 Setting finbot 」─\n"
                                if Disc["sticker"] == True: md+="│ Sticker 『 ON 』\n"
                                else: md+="│ Sticker 『 OFF 』\n"
                                if Disc["contact"] == True: md+="│ Contact 『 ON 』\n"
                                else: md+="│ Contact 『 OFF 』\n"
                                if Disc["talkban"] == True: md+="│ Talkban 『 ON 』\n"
                                else: md+="│ Talkban 『 OFF 』\n"
                                if Disc["Mentionkick"] == True: md+="│ Auto tagkick 『 ON 』\n"
                                else: md+="│ Auto tagkick 『 OFF 』\n"
                                if Disc["detectMention"] == True: md+="│ Auto respon 『 ON 』\n"
                                else: md+="│ Auto respon 『 OFF 』\n"
                                if Disc["autoJoin"] == True: md+="│ Auto join 『 ON 』\n"
                                else: md+="│ Auto join 『 OFF 』\n"
                                if Disc["autoAdd"] == True: md+="│ Auto addfriend 『 ON 』\n"
                                else: md+="│ Auto addfriend 『 OFF 』\n"
                                if msg.to in welcome: md+="│ Welcome 『 ON 』\n"
                                else: md+="│ Welcome 『 OFF 』\n"
                                if Disc["autoLeave"] == True: md+="│ Auto leave 『 ON 』\n"
                                else: md+="│ Auto leave 『 OFF 』\n"
                                if msg.to in protectqr: md+="│ Proqr 『 ON 』\n"
                                else: md+="│ Proqr 『 OFF 』\n"
                                if msg.to in protectjoin: md+="│ Projoin 『 ON 』\n"
                                else: md+="│ Protjoin 『 OFF 』\n"
                                if msg.to in protectkick: md+="│ Promember 『 ON 』\n"
                                else: md+="│ Promember 『 OFF 』\n"
                                if msg.to in protectcancel: md+="│ Protcancel 『 ON 』\n"
                                else: md+="│ Protcancel 『 OFF 』\n╰──────────\n"
                                fino10.sendMessage(msg.to, md+"\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")

                        elif cmd == "creator" or text.lower() == 'creator':
                            if msg._from in admin:
                                fino10.sendMessage(msg.to,"Creator ──┅═ᒯ̶͟ïทᗽ๑tͭ") 
                                ma = ""
                                for i in creator:
                                    ma = fino10.getContact(i)
                                    fino10.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                        elif cmd == "about" or cmd == "informasi":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               sendMention(msg.to, sender, "『 finbot 버전 4』\n")
                               fino10.sendMessage(msg.to, None, contentMetadata={'mid': mid}, contentType=13)
                        elif cmd == "me" or text.lower() == 'me':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': mid}
                               fino10.sendMessage(msg.to,None,contentMetadata = {'mid': mid}, contentType=13)
                        elif text.lower() == "mid":
                               fino10.sendMessage(msg.to, msg._from)
                        elif text.startswith(".get-imagetext"):
                               sep = text.split(" ")
                               textnya = text.replace(sep[0] + " ","")
                               url = "http://chart.apis.google.com/chart?chs=480x80&cht=p3&chtt=" + textnya + "&chts=FFFFFF,70&chf=bg,s,000000"
                               fino10.sendImageWithURL(msg.to, url)
                        elif text.lower() == "meme ":
                               data = msg.text.lower().replace("meme ","")
                               meme = data.split('|')
                               meme = meme[0].replace(' ','_')
                               atas = data.split('|')
                               atas = atas[1].replace(' ','_')
                               bawah = data.split('|')
                               bawah = bawah[2].replace(' ','_')
                               memes = 'https://memegen.link/'+meme+'/'+atas+'/'+bawah+'.jpg'
                               fino10.sendImageWithURL(msg.to,memes)
                        elif ".get-ssweb " in msg.text:
                               website = msg.text.replace(".get-ssweb ","")
                               response = requests.get("http://rahandiapi.herokuapp.com/sswebAPI?key=betakey&link="+website+"")
                               data = response.json()
                               pictweb = data['result']
                               fino10.sendImageWithURL(msg.to,pictweb)
                        elif ".get-ssig " in msg.text:
                               instagram = msg.text.replace(".get-ssig ","")
                               response = requests.get("http://rahandiapi.herokuapp.com/sswebAPI?key=betakey&link=www.instagram.com/"+instagram+"")
                               data = response.json()
                               pictig = data['result']
                               fino10.sendImageWithURL(msg.to,pictig)
                        elif ".get-ssyt " in msg.text:
                               youtube = msg.text.replace(".get-ssyt ","")
                               response = requests.get("http://rahandiapi.herokuapp.com/sswebAPI?key=betakey&link=www.youtube.com/"+youtube+"")
                               data = response.json()
                               pictyt = data['result']
                               fino10.sendImageWithURL(msg.to,pictyt)
                        elif ("Mid " in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = fino10.getContact(key1)
                               fino10.sendMessage(msg.to, "『 Unser Name 』 : "+str(mi.displayName)+"\n『 Unser Mid 』 : " +key1)
                               fino10.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                        elif ("Info " in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = fino10.getContact(key1)
                               fino10.sendMessage(msg.to, "『 Unser Name 』 : "+str(mi.displayName)+"\n『 Unser Mid 』 : " +key1+"\n『 Unser Bio 』 : "+str(mi.statusMessage))
                               fino10.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(fino.getContact(key1)):
                                   fino10.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:
                                   fino10.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))
                                   
                        elif ("token mac" in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	data = {'nama': '{}'.format(msg._from),'submit4': ''}
                            	post_response = requests.post(url = 'https://lazybot.us/snipz/', data = data)
                            	qr = post_response.text
                            	fino10.sendMessage(msg.to, '{}'.format(qr))
                        elif ("token win10" in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	data = {'nama': '{}'.format(msg._from),'submit3': ''}
                            	post_response = requests.post(url = 'https://lazybot.us/snipz/', data = data)
                            	qr = post_response.text
                            	fino10.sendMessage(msg.to, '{}'.format(qr))
                        elif ("token ios" in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	data = {'nama': '{}'.format(msg._from),'submit2': ''}
                            	post_response = requests.post(url = 'https://lazybot.us/snipz/', data = data)
                            	qr = post_response.text
                            	fino10.sendMessage(msg.to, '{}'.format(qr))
                        elif ("token done" in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	data = {'nama': '{}'.format(msg._from),'submit5': ''}
                            	post_response = requests.post(url = 'https://lazybot.us/snipz/', data = data)
                            	qr = post_response.text
                            	fino10.sendMessage(msg.to,"Give thanks for FINBOT\nhere's your Auth token")
                            	fino10.sendMessage(msg.to, '{}'.format(qr))

                        elif cmd == "cek. ":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               fino1.sendMessage(msg.to, None, contentMetadata={'mid': "ud108eea8074da128b9cd064a8a28e27a,'"}, contentType=13)

                        elif cmd == "mybot":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               fino1.sendMessage(msg.to, None, contentMetadata={'mid': Amid}, contentType=13)
                               fino2.sendMessage(msg.to, None, contentMetadata={'mid': Bmid}, contentType=13)
                               fino3.sendMessage(msg.to, None, contentMetadata={'mid': Cmid}, contentType=13)
                               fino4.sendMessage(msg.to, None, contentMetadata={'mid': Dmid}, contentType=13)
                               fino5.sendMessage(msg.to, None, contentMetadata={'mid': Emid}, contentType=13)
                               fino10.sendMessage(msg.to, None, contentMetadata={'mid': Zmid}, contentType=13)
                               fino10.sendMessage(msg.to, None, contentMetadata={'mid': Kmid}, contentType=13)
                               
                        elif text.lower() == "un":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               try:
                                   fino.unsendMessages(op.param2)
                               except:
                                   pass
                        elif text.lower() == "delchat":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               try:
                                   fino.removeAllMessages(op.param2)
                               except:
                                   pass
                        elif text.lower() == "rechat":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               try:
                                   fino1.removeAllMessages(op.param2)
                                   fino2.removeAllMessages(op.param2)
                                   fino3.removeAllMessages(op.param2)
                                   fino4.removeAllMessages(op.param2)
                                   fino5.removeAllMessages(op.param2)
                                   fino10.removeAllMessages(op.param2)
                                   fino10.sendMessage(msg.to,"『 All msg Removed 』")
                               except:
                                   pass
                    
                        elif cmd.startswith("fbroadcast: "):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               text = text.replace(sep[0] + " ","")
                               friends = fino.friends
                               for friend in friends:
                               	fino.sendMessage(friend, "[ Broadcast ]\n{}".format(str(txt)))
                               	fino.sendMessage(msg.to, "Berhasil broadcast ke {} teman".format(str(len(friends))))
                        elif cmd.startswith("allbroadcast: "):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               text = text.replace(sep[0] + " ","")
                               friends = fino.friends
                               groups = fino.getGroups
                               for group in groups:
                                   fino.sendMessage(group,"『 Broadcast 』\n{}".format(str(text)))
                                   fino.sendMessage(msg.to, "Berhasil broadcast ke {} group".format(str(len(groups))))
                               for friend in friends:
                               	fino.sendMessage(friend, "[ Broadcast ]\n{}".format(str(txt)))
                               	fino.sendMessage(msg.to, "Berhasil broadcast ke {} teman".format(str(len(friends))))
                        elif cmd.startswith("broadcast: "):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               text = text.replace(sep[0] + " ","")
                               groups = fino.groups
                               for group in groups:
                                   fino.sendMessage(group,"『 Broadcast 』\n{}".format(str(text)))
                                   fino.sendMessage(msg.to, "Berhasil broadcast ke {} group".format(str(len(groups))))
                        elif text.lower() == "mykey":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               fino10.sendMessage(msg.to, "「Mykey」\nSetkey bot mu「 " + str(Setmain["keyCommand"]) + " 」")
                        elif cmd.startswith("setkey "):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   fino10.sendMessage(msg.to, "Gagal mengganti key")
                               else:
                                   Setmain["keyCommand"] = str(key).lower()
                                   fino10.sendMessage(msg.to, "「Setkey」\nSetkey diganti jadi「{}」".format(str(key).lower()))
                        elif text.lower() == "resetkey":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               Setmain["keyCommand"] = ""
                               fino10.sendMessage(msg.to, "「Setkey」\nSetkey mu kembali ke awal")
                        elif cmd == "reboot":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               fino10.sendMessage(msg.to, "『 Please Wait 』")
                               Setmain["restartPoint"] = msg.to
                               restartBot()
                               fino10.sendMessage(msg.to, "Silahkan gunakan seperti semula...")
                        elif cmd == "runtime":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "『 finbot Version 4 』\n\n『 finbot Aktive 』\n " +waktu(eltime)
                               fino10.sendMessage(msg.to,bot)
 
                        elif cmd == "info group":
                          if msg._from in admin:
                            try:
                                G = fino.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Closed"
                                    gTicket = "No prevent"
                                else:
                                    gQr = "Opened"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(fino.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                fino.sendMessage(msg.to, "『 finbot 번역 Version 4』\n\n『 Unser Name Group 』 : {}".format(G.name)+ "\n『 Unser Mid Group 』 : {}".format(G.id)+ "\n『 Unser Name Creator Group 』 : {}".format(G.creator.displayName)+ "\n『 Since 』 : {}".format(str(timeCreated))+ "\n『 전체 그룹 회원Group member 』 : {}".format(str(len(G.members)))+ "\n『 Jumlah Pending 』 : {}".format(gPending)+ "\n『 Group Qr 』 : {}".format(gQr)+ "\n『 Gurl 』 : {}".format(gTicket))
                                fino.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                fino.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                fino.sendMessage(msg.to, str(e))
                           
                        elif cmd == "ginfo":
                          if msg._from in admin:
                            try:
                                G = fino10.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Closed"
                                    gTicket = "No prevent"
                                else:
                                    gQr = "Opened"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(fino.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                fino10.sendMessage(msg.to, "『 Finbot Version 4』\n\n『 Unser Name Group 』 : {}".format(G.name)+ "\n『 Unser Mid Group 』 : {}".format(G.id)+ "\n『 Unser Name Creator Group 』 : {}".format(G.creator.displayName)+ "\n『 Since 』 : {}".format(str(timeCreated))+ "\n『 Jumlah Member Group 』 : {}".format(str(len(G.members)))+ "\n『 Jumlah Pending 』 : {}".format(gPending)+ "\n『 Group Qr 』 : {}".format(gQr)+ "\n『 Gurl 』 : {}".format(gTicket))
                                fino10.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                fino10.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                fino10.sendMessage(msg.to, str(e))

                        elif cmd.startswith("group "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = fino.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = fino.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Not found"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Closed"
                                    gTicket = "No prevent"
                                else:
                                    gQr = "Opened"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(fino.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "『 Finbot Version 4 』\n"
                                ret_ += "\n『 Unser Name Group 』 : {}".format(G.name)
                                ret_ += "\n『 Unser Group ID 』 : {}".format(G.id)
                                ret_ += "\n『 Unser Name Creator Group 』 : {}".format(gCreator)
                                ret_ += "\n『 Since 』 : {}".format(str(timeCreated))
                                ret_ += "\n『 Total Member 』 : {}".format(str(len(G.members)))
                                ret_ += "\n『 Total Pend 』 : {}".format(gPending)
                                ret_ += "\n『 Group Qr 』 : {}".format(gQr)
                                ret_ += "\n『 Gurl 』 : {}".format(gTicket)
                                ret_ += ""
                                fino.sendMessage(to, str(ret_))
                            except:
                                pass

                        elif cmd.startswith("member "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = fino10.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = fino.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n " "⇨ "+ str(no) + ". " + mem.displayName
                                fino10.sendMessage(to,"『 Unser Name Group 』 :  " + str(G.name) + " \n\n『 Unser Name Member 』\n" + ret_ + "\n\n『 Total Member %i 』" % len(G.members))
                            except: 
                                pass

                        elif cmd.startswith("leave: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = fino.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            for i in group:
                                ginfo = fino.getGroup(i)
                                if ginfo == group:
                                    fino1.leaveGroup(i)
                                    fino2.leaveGroup(i)
                                    fino3.leaveGroup(i)
                                    fino4.leaveGroup(i)
                                    fino5.leaveGroup(i)
                                    fino10.sendMessage(msg.to,"Access granted out from group\n" +str(ginfo.name))

                        elif cmd == "friendlist":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = fino.getAllContactIds()
                               for i in gid:
                                   G = fino.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "│◇ " + str(a) + ". " +G.displayName+ "\n"
                               fino.sendMessage(msg.to,"『 Unser Name Friend 』\n"+ma+"\n『 Total「"+str(len(gid))+"」Friends 』")
                               
                        elif cmd == ".group":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = fino.getGroupIdsJoined()
                               for i in gid:
                                   G = fino.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "│ " + str(a) + ". " +G.name+ "\n"
                               fino.sendMessage(msg.to,"╭─「 Group 」─\n"+ma+"\n╰──────────\n『Total「"+str(len(gid))+"」Groups』\nFor See List Group member type⇣\n[Ex] Member 1\n\nFor See List Group type⇣\n[Ex] Group 1")
                               
                        elif cmd == "open":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = fino10.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   fino10.updateGroup(X)
                                   fino10.sendMessage(msg.to, "Url Opened")
                        elif cmd == "close":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = fino10.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   fino10.updateGroup(X)
                                   fino10.sendMessage(msg.to, "Url Closed")
                        elif cmd == "gurl":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   x = fino10.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      fino10.updateGroup(x)
                                   gurl = fino10.reissueGroupTicket(msg.to)
                                   fino10.sendMessage(msg.to, "『 Unser Name Group 』  : "+str(x.name)+ "\n『 Gurl 』  : http://line.me/R/ti/g/"+gurl)
#===========BOT UPDATE============#
                        elif cmd.startswith("addsticker "):
                          if msg._from in admin:
                            sep = text.split(" ")
                            name = text.replace(sep[0] + " ","")
                            name = name.lower()
                            if name not in stickers:
                                Disc["Addsticker"]["status"] = True
                                Disc["Addsticker"]["name"] = str(name.lower())
                                stickers[str(name.lower())] = ""
                                with open("sticker.json","w") as fp:
                                	json.dump(stickers, f, sort_keys=True, indent=4)
                                fino10.sendMessage(msg.to, "Send a sticker added to disc")
                            else:
                                fino10.sendMessage(msg.to, "Sticker already exist")
                        elif cmd == "list sticker" or cmd == " list sticker":
                                if msg._from in admin:
                                    load()
                                    ret_ = "╭─「 Sticker 」─"
                                    num = 1
                                    for sticker in stickers:
                                        ret_ += "\n│{}. {}".format(str(num), str(sticker.title()))
                                        num = (num+1)
                                    ret_ += "\n╰──────────"
                                    fino10.sendMessage(to, ret_)

                        elif cmd == "addimage":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                Setmain["Addimage"] = True
                                fino10.sendMessage(msg.to,"『 Send image to upload 』")
                        elif cmd == "updatefoto":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Setmain["foto"][mid] = True
                                fino10.sendMessage(msg.to,"『 Send image to upload 』")
                        elif cmd == "cfoto":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Setmain["changePicture"] = True
                                fino10.sendMessage(msg.to,"『 Send image to upload 』")
                        elif cmd == "cfotogroup":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                Setmain["groupPicture"] = True
                                fino10.sendMessage(msg.to,"『 Send image to upload 』")
                        elif cmd.startswith("cname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 500:
                                profile = fino.getProfile()
                                profile.displayName = string
                                fino.updateProfile(profile)
                                fino10.sendMessage(msg.to,"Name changed to " + string + "")
                        elif cmd.startswith("captename: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 500:
                                profile = fino10.getProfile()
                                profile.displayName = string
                                fino10.updateProfile(profile)
                                fino10.sendMessage(msg.to,"Name changed to " + string + "")
                        elif cmd.startswith("bot1name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 500:
                                profile = fino1.getProfile()
                                profile.displayName = string
                                fino1.updateProfile(profile)
                                fino1.sendMessage(msg.to,"Name changed to " + string + "")
                        elif cmd.startswith("bot2name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 500:
                                profile = fino2.getProfile()
                                profile.displayName = string
                                fino2.updateProfile(profile)
                                fino2.sendMessage(msg.to,"Name changed to " + string + "")
                        elif cmd.startswith("bot3name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 500:
                                profile = fino3.getProfile()
                                profile.displayName = string
                                fino3.updateProfile(profile)
                                fino3.sendMessage(msg.to,"Name changed to " + string + "")
                        elif cmd.startswith("bot4name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 500:
                                profile = fino4.getProfile()
                                profile.displayName = string
                                fino4.updateProfile(profile)
                                fino4.sendMessage(msg.to,"Name changed to " + string + "")
                        elif cmd.startswith("captename: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 500:
                                profile = fino10.getProfile()
                                profile.displayName = string
                                fino10.updateProfile(profile)
                                fino10.sendMessage(msg.to,"Name changed to " + string + "")
                        elif cmd.startswith("allname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 500:
                                profile = fino4.getProfile()
                                profile.displayName = string
                                fino4.updateProfile(profile)
                                fino4.sendMessage(msg.to,"Name changed to " + string + "")
                                profile = fino1.getProfile()
                                profile.displayName = string
                                fino1.updateProfile(profile)
                                fino1.sendMessage(msg.to,"Name changed to " + string + "")
                                profile = fino2.getProfile()
                                profile.displayName = string
                                fino2.updateProfile(profile)
                                fino2.sendMessage(msg.to,"Name changed to " + string + "")
                                profile = fino3.getProfile()
                                profile.displayName = string
                                fino3.updateProfile(profile)
                                fino3.sendMessage(msg.to,"Name changed to " + string + "")
                                profile = fino4.getProfile()
                                profile.displayName = string
                                fino4.updateProfile(profile)
                                fino4.sendMessage(msg.to,"Name changed to " + string + "")
                                profile = fino5.getProfile()
                                profile.displayName = string
                                fino5.updateProfile(profile)
                                fino5.sendMessage(msg.to,"Name changed to " + string + "")
                                
#create backup/restore backup Name/Status /profile pict
                        elif cmd == "bot1 backup run" or text.lower() == 'bot1 backup run':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	wek = fino1.getContact(Amid)
                            	a = wek.pictureStatus
                            	r = wek.displayName
                            	i = wek.statusMessage
                            	s = open('finbot1.txt',"w")
                            	s.write(r)
                            	s.close()
                            	t = open('finbot01.txt',"w")
                            	t.write(i)
                            	t.close()
                            	u = open('finbot001.txt',"w")
                            	u.write(a)
                            	u.close()
                            	fino1.sendMessage(msg.to, "Finbot1 Backup created")
                        elif cmd == "bot2 backup run" or text.lower() == 'bot2 backup run':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	wek = fino2.getContact(Bmid)
                            	a = wek.pictureStatus
                            	r = wek.displayName
                            	i = wek.statusMessage
                            	s = open('finbot2.txt',"w")
                            	s.write(r)
                            	s.close()
                            	t = open('finbot02.txt',"w")
                            	t.write(i)
                            	t.close()
                            	u = open('finbot002.txt',"w")
                            	u.write(a)
                            	u.close()
                            	fino2.sendMessage(msg.to, "Finbot2 Backup created")
                        elif cmd == "bot3 backup run" or text.lower() == 'bot3 backup run':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	wek = fino3.getContact(Cmid)
                            	a = wek.pictureStatus
                            	r = wek.displayName
                            	i = wek.statusMessage
                            	s = open('finbot3.txt',"w")
                            	s.write(r)
                            	s.close()
                            	t = open('finbot03.txt',"w")
                            	t.write(i)
                            	t.close()
                            	u = open('finbot003.txt',"w")
                            	u.write(a)
                            	u.close()
                            	fino3.sendMessage(msg.to, "Finbot3 Backup created")
                        elif cmd == "bot4 backup run" or text.lower() == 'bot4 backup run':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	wek = fino4.getContact(Dmid)
                            	a = wek.pictureStatus
                            	r = wek.displayName
                            	i = wek.statusMessage
                            	s = open('finbot4.txt',"w")
                            	s.write(r)
                            	s.close()
                            	t = open('finbot04.txt',"w")
                            	t.write(i)
                            	t.close()
                            	u = open('finbot004.txt',"w")
                            	u.write(a)
                            	u.close()
                            	fino4.sendMessage(msg.to, "Finbot4 Backup created")
                        elif cmd == "bot5 backup run" or text.lower() == 'bot5 backup run':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	wek = fino5.getContact(Emid)
                            	a = wek.pictureStatus
                            	r = wek.displayName
                            	i = wek.statusMessage
                            	s = open('finbot5.txt',"w")
                            	s.write(r)
                            	s.close()
                            	t = open('finbot05.txt',"w")
                            	t.write(i)
                            	t.close()
                            	u = open('finbot005.txt',"w")
                            	u.write(a)
                            	u.close()
                            	fino5.sendMessage(msg.to, "Finbot5 Backup created")
                        elif cmd == "talk backup run" or text.lower() == 'talk backup run':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	wek = fino10.getContact(Zmid)
                            	a = wek.pictureStatus
                            	r = wek.displayName
                            	i = wek.statusMessage
                            	s = open('finbottalk.txt',"w")
                            	s.write(r)
                            	s.close()
                            	t = open('finbottalks.txt',"w")
                            	t.write(i)
                            	t.close()
                            	u = open('finbottalkss.txt',"w")
                            	u.write(a)
                            	u.close()
                            	fino10.sendMessage(msg.to, "Finbot talk group Backup created")
                            
                        elif cmd == "bot1 restore" or text.lower() == 'bot1 backup':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	h = open('finbot1.txt',"r")
                            	name = h.read()
                            	h.close()
                            	x = name
                            	profile = fino1.getProfile()
                            	profile.displayName = x
                            	fino.updateProfile(profile)
                            	i = open('finbot01.txt',"r")
                            	sm = i.read()
                            	i.close()
                            	y = sm
                            	cak = fino1.getProfile()
                            	cak.statusMessage = y
                            	fino.updateProfile(cak)
                            	j = open('finbot001.txt',"r")
                            	ps = j.read()
                            	j.close()
                            	p = ps
                            	fino1.updateProfilePicture(p)
                            	fino1.sendMessage(msg.to, "Finbot1 Backup restored")
                        elif cmd == "bot2 restore" or text.lower() == 'bot2 backup':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	h = open('finbot2.txt',"r")
                            	name = h.read()
                            	h.close()
                            	x = name
                            	profile = fino2.getProfile()
                            	profile.displayName = x
                            	fino.updateProfile(profile)
                            	i = open('finbot02.txt',"r")
                            	sm = i.read()
                            	i.close()
                            	y = sm
                            	cak = fino2.getProfile()
                            	cak.statusMessage = y
                            	fino.updateProfile(cak)
                            	j = open('finbot002.txt',"r")
                            	ps = j.read()
                            	j.close()
                            	p = ps
                            	fino2.updateProfilePicture(p)
                            	fino2.sendMessage(msg.to, "Finbot2 Backup restored")
                        elif cmd == "bot3 restore" or text.lower() == 'bot3 backup':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	h = open('finbot3.txt',"r")
                            	name = h.read()
                            	h.close()
                            	x = name
                            	profile = fino3.getProfile()
                            	profile.displayName = x
                            	fino.updateProfile(profile)
                            	i = open('finbot03.txt',"r")
                            	sm = i.read()
                            	i.close()
                            	y = sm
                            	cak = fino3.getProfile()
                            	cak.statusMessage = y
                            	fino.updateProfile(cak)
                            	j = open('finbot003.txt',"r")
                            	ps = j.read()
                            	j.close()
                            	p = ps
                            	fino3.updateProfilePicture(p)
                            	fino3.sendMessage(msg.to, "Finbot3 Backup restored")
                        elif cmd == "bot4 restore" or text.lower() == 'bot4 backup':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	h = open('finbot4.txt',"r")
                            	name = h.read()
                            	h.close()
                            	x = name
                            	profile = fino4.getProfile()
                            	profile.displayName = x
                            	fino.updateProfile(profile)
                            	i = open('finbot04.txt',"r")
                            	sm = i.read()
                            	i.close()
                            	y = sm
                            	cak = fino4.getProfile()
                            	cak.statusMessage = y
                            	fino.updateProfile(cak)
                            	j = open('finbot004.txt',"r")
                            	ps = j.read()
                            	j.close()
                            	p = ps
                            	fino4.updateProfilePicture(p)
                            	fino4.sendMessage(msg.to, "Finbot4 Backup restored")
                        elif cmd == "bot5 restore" or text.lower() == 'bot5 backup':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	h = open('finbot5.txt',"r")
                            	name = h.read()
                            	h.close()
                            	x = name
                            	profile = fino5.getProfile()
                            	profile.displayName = x
                            	fino.updateProfile(profile)
                            	i = open('finbot05.txt',"r")
                            	sm = i.read()
                            	i.close()
                            	y = sm
                            	cak = fino5.getProfile()
                            	cak.statusMessage = y
                            	fino.updateProfile(cak)
                            	j = open('finbot005.txt',"r")
                            	ps = j.read()
                            	j.close()
                            	p = ps
                            	fino5.updateProfilePicture(p)
                            	fino5.sendMessage(msg.to, "Finbot5 Backup restored")
                        elif cmd == "talk restore" or text.lower() == 'talk backup':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                            	h = open('finbottalk.txt',"r")
                            	name = h.read()
                            	h.close()
                            	x = name
                            	profile = fino10.getProfile()
                            	profile.displayName = x
                            	fino.updateProfile(profile)
                            	i = open('finbottalks.txt',"r")
                            	sm = i.read()
                            	i.close()
                            	y = sm
                            	cak = fino10.getProfile()
                            	cak.statusMessage = y
                            	fino.updateProfile(cak)
                            	j = open('finbottalkss.txt',"r")
                            	ps = j.read()
                            	j.close()
                            	p = ps
                            	fino10.updateProfilePicture(p)
                            	fino10.sendMessage(msg.to, "Finbot talk Backup restored")

#===========BOT UPDATE============#
                        elif cmd == "mention" or text.lower() == 'mention':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               group = fino.getGroup(msg.to)
                               nama = [contact.mid for contact in group.members]
                               nm1, nm2, nm3, nm4, jml = [], [], [], [], len(nama)
                               if jml <= 100:
                                   mentionMembers(msg.to, nama)
                               if jml > 100 and jml < 200:
                                   for i in range (0, 99):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (100, len(nama)-1):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                               if jml > 200 and jml < 300:
                                   for i in range (0, 99):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (100, 199):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (200, len(nama)-1):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                               if jml > 300 and jml < 400:
                                   for i in range (0, 99):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (100, 199):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (200, 299):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (300, len(nama)-1):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                               if jml > 400 and jml < 500:
                                   for i in range (0, 99):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (100, 199):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (200, 299):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (300, 399):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (400, len(nama)-1):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)

                        elif cmd == "joinall":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                G = fino10.getGroup(msg.to)
                                ginfo = fino10.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                fino10.updateGroup(G)
                                invsend = 0
                                Ticket = fino10.reissueGroupTicket(msg.to)
                                fino1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                fino2.acceptGroupInvitationByTicket(msg.to,Ticket)
                                fino3.acceptGroupInvitationByTicket(msg.to,Ticket)
                                fino4.acceptGroupInvitationByTicket(msg.to,Ticket)
                                fino5.acceptGroupInvitationByTicket(msg.to,Ticket)
#                                fino6.acceptGroupInvitationByTicket(msg.to,Ticket)
 #                               fino7.acceptGroupInvitationByTicket(msg.to,Ticket)
  #                              fino8.acceptGroupInvitationByTicket(msg.to,Ticket)
   #                             fino9.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = fino10.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                fino10.updateGroup(G)
                        elif cmd == "fin1":
                            if msg._from in admin:
                                G = fino10.getGroup(msg.to)
                                ginfo = fino10.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                fino10.updateGroup(G)
                                invsend = 0
                                Ticket = fino10.reissueGroupTicket(msg.to)
                                fino1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = fino1.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                fino1.updateGroup(G)
                        elif cmd == "fin2":
                            if msg._from in admin:
                                G = fino10.getGroup(msg.to)
                                ginfo = fino10.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                fino10.updateGroup(G)
                                invsend = 0
                                Ticket = fino10.reissueGroupTicket(msg.to)
                                fino2.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = fino2.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                fino2.updateGroup(G)
                        elif cmd == "fin3":
                            if msg._from in admin:
                                G = fino10.getGroup(msg.to)
                                ginfo = fino10.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                fino10.updateGroup(G)
                                invsend = 0
                                Ticket = fino10.reissueGroupTicket(msg.to)
                                fino3.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = fino3.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                fino3.updateGroup(G)
                        elif cmd == "fin4":
                            if msg._from in admin:
                                G = fino10.getGroup(msg.to)
                                ginfo = fino10.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                fino10.updateGroup(G)
                                invsend = 0
                                Ticket = fino10.reissueGroupTicket(msg.to)
                                fino4.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = fino4.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                fino4.updateGroup(G)
                        elif cmd == "fin5":
                            if msg._from in admin:
                                G = fino10.getGroup(msg.to)
                                ginfo = fino10.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                fino10.updateGroup(G)
                                invsend = 0
                                Ticket = fino10.reissueGroupTicket(msg.to)
                                fino5.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = fino5.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                fino5.updateGroup(G)

                        elif cmd == "talk join":
                            if msg._from in admin:
                                G = fino.getGroup(msg.to)
                                ginfo = fino.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                fino.updateGroup(G)
                                invsend = 0
                                Ticket = fino.reissueGroupTicket(msg.to)
                                fino10.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = fino10.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                fino10.updateGroup(G)
                        elif cmd == "kicker join":
                            if msg._from in admin:
                                G = fino10.getGroup(msg.to)
                                ginfo = fino10.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                fino10.updateGroup(G)
                                invsend = 0
                                Ticket = fino10.reissueGroupTicket(msg.to)
                                sw1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = sw1.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                sw1.updateGroup(G)
                        elif cmd == "hei":
                            if msg._from in admin:
                                fino10.inviteIntoGroup(msg.to,[Amid])
                                fino10.inviteIntoGroup(msg.to,[Bmid])
                                fino10.inviteIntoGroup(msg.to,[Cmid])
                                fino10.inviteIntoGroup(msg.to,[Dmid])
                                fino10.inviteIntoGroup(msg.to,[Emid])
                                fino1.acceptGroupInvitation(msg.to)
                                fino2.acceptGroupInvitation(msg.to)
                                fino3.acceptGroupInvitation(msg.to)
                                fino4.acceptGroupInvitation(msg.to)
                                fino5.acceptGroupInvitation(msg.to)

                        elif cmd == "talk":
                            if msg._from in admin:
                                fino.inviteIntoGroup(msg.to,[Zmid])
                                fino10.acceptGroupInvitation(msg.to)
                            else:
                            	fino10.sendMessage(msg.to,"I'm here boss")

                        elif cmd == "finbye":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                G = fino.getGroup(msg.to)
                                fino1.sendMessage(msg.to, "안녕 모두 미안해...!"+str(G.name))
                                fino1.leaveGroup(msg.to)
                                fino2.leaveGroup(msg.to)
                                fino3.leaveGroup(msg.to)
                                fino4.leaveGroup(msg.to)
                                fino5.leaveGroup(msg.to)
#                                fino6.leaveGroup(msg.to)
 #                               fino7.leaveGroup(msg.to)
  #                              fino8.leaveGroup(msg.to)
    #                            fino9.leaveGroup(msg.to)
                        elif cmd == "fin1bye":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                G = fino.getGroup(msg.to)
                                fino1.sendMessage(msg.to, "안녕 모두 미안해....!"+str(G.name))
                                fino1.leaveGroup(msg.to)
                                fino2.leaveGroup(msg.to)
                                fino3.leaveGroup(msg.to)
                                fino4.leaveGroup(msg.to)

                        elif cmd == "byeme":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                G = fino.getGroup(msg.to)
                                fino10.sendMessage(msg.to, "안녕 모두 미안해...!"+str(G.name))
                                fino10.leaveGroup(msg.to)
                        elif cmd.startswith("leave "):
                            if msg._from in admin:
                                proses = text.split(" ")
                                ng = text.replace(proses[0] + " ","")
                                gid = fino.getGroupIdsJoined()
                                for i in gid:
                                    h = fino.getGroup(i).name
                                    if h == ng:
                                        fino1.sendMessage(i, "Please invite admin or get creator back")
                                        fino1.leaveGroup(i)
                                        fino2.leaveGroup(i)
                                        fino3.leaveGroup(i)
                                        fino10.sendMessage(to,"out off all grup " +h)
                        elif cmd == "kicker bye":
                            if msg._from in admin:
                                G = fino.getGroup(msg.to)
                                sw1.leaveGroup(msg.to)
                        elif cmd == "respon":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                fino10.sendMessage(msg.to,responsename)

                        elif cmd == "respon2":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                fino10.sendMessage(msg.to,responsename)
                                fino1.sendMessage(msg.to,responsename1)
                                fino2.sendMessage(msg.to,responsename2)
                                fino3.sendMessage(msg.to,responsename3)
                                fino4.sendMessage(msg.to,responsename4)
                        elif cmd == "crot":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                fino1.sendMessage(msg.to,"crot diluar")
                                fino2.sendMessage(msg.to,"crot di dalam")
                                fino3.sendMessage(msg.to,"apapun crotnya")
                                fino4.sendMessage(msg.to,"yg penting lemes.... ")
                                fino5.sendMessage(msg.to,"yg penting lemes.... ")
                                fino10.sendMessage(msg.to,"Udah crot boss...?")
                        elif cmd == "absen":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                fino1.sendMessage(msg.to,"언제나1")
                                fino2.sendMessage(msg.to,"언제나2")
                                fino3.sendMessage(msg.to,"언제나3")
                                fino4.sendMessage(msg.to,"언제나4")
                                fino5.sendMessage(msg.to,"언제나5")
#                                fino6.sendMessage(msg.to,"언제나6")
 #                               fino7.sendMessage(msg.to,"언제나7")
  #                              fino8.sendMessage(msg.to,"언제나8")
   #                             fino9.sendMessage(msg.to,"언제나9")
                        elif cmd == "sprespon":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                get_profile_time_start = time.time()
                                get_profile = fino10.getProfile()
                                get_profile_time = time.time() - get_profile_time_start
                                get_group_time_start = time.time()
                                get_group = fino10.getGroupIdsJoined()
                                get_group_time = time.time() - get_group_time_start
                                get_contact_time_start = time.time()
                                get_contact = fino10.getContact(mid)
                                get_contact_time = time.time() - get_contact_time_start
                                fino10.sendMessage(msg.to, "♐ || Speed respon\n\n - Get Profile\n   %.10f\n - Get Contact\n   %.10f\n - Get Group\n   %.10f" % (get_profile_time/3,get_contact_time/3,get_group_time/3))
                        elif cmd == "speed" or cmd == "sp":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               start = time.time()
                               fino10.sendMessage(msg.to, "속도 진행...")
                               elapsed_time = time.time() - start
                               fino10.sendMessage(msg.to, "{} /seconds".format(str(elapsed_time)))
                        elif cmd == "lurking on":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 Setmain['readPoint'][msg.to] = msg_id
                                 Setmain['readMember'][msg.to] = {}
                                 fino10.sendMessage(msg.to, "Lurking Enable\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                        elif cmd == "lurking off":
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 del Setmain['readPoint'][msg.to]
                                 del Setmain['readMember'][msg.to]
                                 fino10.sendMessage(msg.to, "Lurking disable\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                        elif cmd == "lurkers":
                          if msg._from in admin:
                            if msg.to in Setmain['readPoint']:
                                if Setmain['readMember'][msg.to] != {}:
                                    aa = []
                                    for x in Setmain['readMember'][msg.to]:
                                        aa.append(x)
                                    try:
                                        arrData = ""
                                        textx = "  [ Result {} member ]    \n\n  [ Lurkers ]\n1. ".format(str(len(aa)))
                                        arr = []
                                        no = 1
                                        b = 1
                                        for i in aa:
                                            b = b + 1
                                            end = "\n"
                                            mention = "@x\n"
                                            slen = str(len(textx))
                                            elen = str(len(textx) + len(mention) - 1)
                                            arrData = {'S':slen, 'E':elen, 'M':i}
                                            arr.append(arrData)
                                            tz = pytz.timezone("Asia/Jakarta")
                                            timeNow = datetime.now(tz=tz)
                                            textx += mention
                                            if no < len(aa):
                                                no += 1
                                                textx += str(b) + ". "
                                            else:
                                                try:
                                                    no = "[ {} ]".format(str(fino.getGroup(msg.to).name))
                                                except:
                                                    no = "  "
                                        msg.to = msg.to
                                        fino10.sendMessage(msg.to,textx+"\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]",contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')},contentType = 0)
                                    except:
                                        pass
                                    try:
                                        del Setmain['readPoint'][msg.to]
                                        del Setmain['readMember'][msg.to]
                                    except:
                                        pass
                                    Setmain['readPoint'][msg.to] = msg.id
                                    Setmain['readMember'][msg.to] = {}
                                else:
                                    fino10.sendMessage(msg.to, "Seens empty...")
                            else:
                                    fino10.sendMessage(msg.to, "Please type lurking on before.. ")

                        elif cmd == "cctv":
                          if wait["finbot"] == True:
                           if msg._from in admin:
                           	fino10.sendMessage(msg.to,"checking viewers")
                           try:
                           	del Setmain['readPoint'][msg.to]
                           	del Setmain['readMember'][msg.to]
                           except:
                           	pass
                           now2 = datetime.now()
                           Setmain['readPoint'][msg.to] = msg.id
                           Setmain['readMember'][msg.to] = ""
                           Setmain['setTime'][msg.to] = datetime.strftime(now2,"%H:%M")
                           Setmain['ROM'][msg.to] = {}

                        elif cmd == "seens":
                          if wait["finbot"] == True:
                           if msg._from in admin:
                            if msg.to in Setmain['readPoint']:
                             if Setmain["ROM"][msg.to].items() == []:
                           	  chiya = ""
                           else:
                           	  chiya = ""
                           for rom in Setmain["ROM"][msg.to].items():
                           #	print rom
                               chiya += rom[1] + "\n"
                               fino10.sendMessage(msg.to, "╔══════════\n║[Di Read Oleh]\n╚══════════\n%s\n╔══════════\n║Pelaku CCTV\n╚══════════\n%s\n╔══════════\n║-=CCTV=-\n║Ngintip bintitan\n║7Turunan\n║6Tanjakan\n║5Tikungan\n╚══════════\n[%s]" % (Setmain['readMember'][msg.to],chiya,setTime[msg.to])) 
                          else: 
                           	fino10.sendMessage(msg.to, "Type cctv before...  you can't look up seens list") 

                        elif cmd == "sider on":
                          if wait["finbot"] == True:
                           if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  fino10.sendMessage(msg.to, "Cek sider Enable\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True
                        elif cmd == "sider off":
                          if wait["finbot"] == True:
                           if msg._from in admin:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  fino10.sendMessage(msg.to, "Cek sider Disable\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                              else:
                                  fino10.sendMessage(msg.to, "Sudak tidak aktif")
#===========Hiburan============#
                        elif Disc['key']+'smsin ' in text:
                            try:
                                sms = text.replace(Disc['key']+'smsin ','').split(',')
                                a = {'no': sms[0],'text': sms[1]}
                                r = requests.get('http://corrykalam.gq/sms.php?', params=a).json()
                                re = ''
                                if r['status'] == 'Sukses':re+='Status : Sukses\nNo. Tujuan : %s\nPesan : %s\nDetail : %s' % (sms[0],sms[1],r['detail'])
                                else:re+='Status : Gagal\nNo. Tujuan : %s\nPesan : %s\nDetail : %s' % (sms[0],sms[1],r['detail'])
                                fino10.sendMessage(receiver,re)
                            except Exception as e:
                                fino10.sendMessage(receiver,str(e))
                                logError(e)
#TEXTTOSPEECH
                        elif msg.text.lower().startswith("say-af "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'af'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-sq "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'sq'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-ar "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'ar'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-hy "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'hy'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-bn "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'bn'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-ca "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'ca'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-zh "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'zh'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-zh-cn "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'zh-cn'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-zh-tw "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'zh-tw'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-zh-yue "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'zh-yue'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-hr "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'hr'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-cs "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'cs'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-da "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'da'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-nl "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'nl'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-en "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'en'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-en-au "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'en-au'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-en-uk "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'en-uk'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-en-us "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'en-us'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-eo "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'eo'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-fi "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'fi'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-fr "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'fr'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-de "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'de'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-el "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'el'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-hi "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'hi'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-hu "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'hu'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-is "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'is'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-id "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'id'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-it "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'it'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-ja "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'ja'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-km "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'km'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-ko "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'ko'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-la "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'la'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-lv "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'lv'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-mk "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'mk'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-no "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'no'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-pl "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'pl'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-pt "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'pt'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-ro "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'ro'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-th "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             say = text.replace(sep[0] + " ","")
                             lang = 'th'
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(msg.to,"hasil.mp3")
                        elif msg.text.lower().startswith("say-"):
                          if msg._from in admin:
                             sep = text.split("-")
                             sep = sep[1].split(" ")
                             lang = sep[0]
                             say = text.replace("say-" + lang + " ","")
                             if lang not in list_language["list_textToSpeech"]:
                             	return fino10.sendMessage(to, "Language not found")
                             tts = gTTS(text=say, lang=lang)
                             tts.save("hasil.mp3")
                             fino10.sendAudio(to,"hasil.mp3")
#TRANSLATOR
                        elif msg.text.lower().startswith("tr-af "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             isi = text.replace(sep[0] + " ","")
                             translator = Translator()
                             hasil = translator.translate(isi, dest='af')
                             A = hasil.text
                             fino10.sendMessage(msg.to, A)
                        elif msg.text.lower().startswith("tr-sq "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             isi = text.replace(sep[0] + " ","")
                             translator = Translator()
                             hasil = translator.translate(isi, dest='sq')
                             A = hasil.text
                             fino10.sendMessage(msg.to, A)
                        elif msg.text.lower().startswith("tr-sq "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             isi = text.replace(sep[0] + " ","")
                             translator = Translator()
                             hasil = translator.translate(isi, dest='sq')
                             A = hasil.text
                             fino10.sendMessage(msg.to, A)
                        elif msg.text.lower().startswith("tr-id "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             isi = text.replace(sep[0] + " ","")
                             translator = Translator()
                             hasil = translator.translate(isi, dest='id')
                             A = hasil.text
                             fino10.sendMessage(msg.to, A)
                        elif msg.text.lower().startswith("tr-en "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             isi = text.replace(sep[0] + " ","")
                             translator = Translator()
                             hasil = translator.translate(isi, dest='en')
                             A = hasil.text
                             fino10.sendMessage(msg.to, A)
                        elif msg.text.lower().startswith("tr-ko "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             isi = text.replace(sep[0] + " ","")
                             translator = Translator()
                             hasil = translator.translate(isi, dest='ko')
                             A = hasil.text
                             fino10.sendMessage(msg.to, A)
                        elif msg.text.lower().startswith("tr-th "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             isi = text.replace(sep[0] + " ","")
                             translator = Translator()
                             hasil = translator.translate(isi, dest='th')
                             A = hasil.text
                             fino10.sendMessage(msg.to, A)
                        elif msg.text.lower().startswith("tr-ar "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             isi = text.replace(sep[0] + " ","")
                             translator = Translator()
                             hasil = translator.translate(isi, dest='ar')
                             A = hasil.text
                             fino10.sendMessage(msg.to, A)
                        elif msg.text.lower().startswith("tr-"):
                          if msg._from in admin:
                             sep = text.split("-")
                             sep = sep[1].split(" ")
                             lang = sep[0]
                             say = text.replace("tr-" + lang + " ","")
                             if lang not in list_language["list_translate"]:
                             	return fino10.sendMessage(to, "Language not found")
                             translator = Translator()
                             hasil = translator.translate(say, dest=lang)
                             A = hasil.text
                             fino10.sendMessage(to, str(A))
      
                        elif cmd.startswith(".get-sholat: "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             location = text.replace(sep[0] + " ","")
                             with requests.session() as web:
                                  web.headers["user-agent"] = random.choice(Setmain["userAgent"])
                                  r = web.get("http://api.corrykalam.net/apisholat.php?lokasi={}".format(urllib.parse.quote(location)))
                                  data = r.text
                                  data = json.loads(data)
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  if data[1] != "Subuh : " and data[2] != "Dzuhur : " and data[3] != "Ashar : " and data[4] != "Maghrib : " and data[5] != "Isha : ":
                                         ret_ = "╭─「 Jadwal Sholat 」─"
                                         ret_ += "\n│❂͜͡➣ Lokasi : " + data[0]
                                         ret_ += "\n│❂͜͡➣ " + data[1]
                                         ret_ += "\n│❂͜͡➣ " + data[2]
                                         ret_ += "\n│❂͜͡➣ " + data[3]
                                         ret_ += "\n│❂͜͡➣ " + data[4]
                                         ret_ += "\n│❂͜͡➣ " + data[5]
                                         ret_ += "\n╰──────────\nDate : " + datetime.strftime(timeNow,'%Y-%m-%d')
                                         ret_ += "\nHours : " + datetime.strftime(timeNow,'%H:%M:%S')
                                  fino10.sendMessage(msg.to, str(ret_))

                        elif cmd.startswith(".get-cuaca: "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            location = text.replace(separate[0] + " ","")
                            with requests.session() as web:
                                web.headers["user-agent"] = random.choice(Setmain["userAgent"])
                                r = web.get("http://api.corrykalam.net/apicuaca.php?kota={}".format(urllib.parse.quote(location)))
                                data = r.text
                                data = json.loads(data)
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                if "result" not in data:
                                    ret_ = "╭─「 Cuaca 」─"
                                    ret_ += "\n│◆ Lokasi : " + data[0].replace("Temperatur di kota ","")
                                    ret_ += "\n│◆ Suhu : " + data[1].replace("Suhu : ","") + " C"
                                    ret_ += "\n│◆ Kelembaban : " + data[2].replace("Kelembaban : ","") + " %"
                                    ret_ += "\n│◆ Tekanan udara : " + data[3].replace("Tekanan udara : ","") + " HPa"
                                    ret_ += "\n│◆ Kecepatan angin : " + data[4].replace("Kecepatan angin : ","") + " m/s"
                                    ret_ += "\n╰──────────\nDate : " + datetime.strftime(timeNow,'%Y-%m-%d')
                                    ret_ += "\nHours : " + datetime.strftime(timeNow,'%H:%M:%S')
                                fino10.sendMessage(msg.to,str(ret_))

                        elif cmd.startswith(".get-lokasi: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            location = msg.text.replace(separate[0] + " ","")
                            with requests.session() as web:
                                web.headers["user-agent"] = random.choice(Setmain["userAgent"])
                                r = web.get("http://api.corrykalam.net/apiloc.php?lokasi={}".format(urllib.parse.quote(location)))
                                data = r.text
                                data = json.loads(data)
                                if data[0] != "" and data[1] != "" and data[2] != "":
                                    link = "https://www.google.co.id/maps/@{},{},15z".format(str(data[1]), str(data[2]))
                                    ret_ = "╭─「 Lokasi 」─"
                                    ret_ += "\n│❂͜͡➣ Location : " + data[0]
                                    ret_ += "\n│❂͜͡➣ Google Maps : " + link
                                else:
                                    ret_ = "[Details Location] Error : Location not found"
                                fino10.sendMessage(msg.to,str(ret_))

                        elif cmd.startswith("musik "):
                           if msg._from in admin:
                           	judul = msg.text.replace("musik ","")
                           params = {"judul": judul}
                           r = requests.get("http://farzain.xyz/api/joox.php?id="+urllib.urlencode(params))
                           data = r.text
                           data = json.loads(data)
                           info = data["info"]
                           audio = data["audio"]
                           hasil = "「 Hasil Musik 」\n"
                           hasil += "\nPenyanyi : {}".format(str(info["penyanyi"]))
                           hasil += "\nJudul : {}".format(str(info["judul"]))
                           hasil += "\nAlbum : {}".format(str(info["album"]))
                           hasil += "\n\nLink : \n1. Image : {}".format(str(data["gambar"]))
                           hasil += "\n\nLink : \n2. MP3 : {}".format(str(audio["mp3"]))
                           hasil += "\n\nLink : \n3. M4A : {}".format(str(audio["m4a"]))
                           fino10.sendImageWithURL(msg.to, str(data["gambar"]))
                           fino10.sendMessage(msg.to, str(hasil))
                           fino10.sendMessage(msg.to, "Downloading...")
                           fino10.sendMessage(msg.to, "「 Result MP3 」")
                           fino10.sendAudioWithURL(msg.to, str(audio["mp3"]))
                           fino10.sendMessage(msg.to, "「 Result M4A 」")
                           fino10.sendVideoWithURL(msg.to, str(audio["m4a"]))

                        elif cmd.startswith("image: "):
                          if msg._from in admin:
                            sep = msg.text.split(" ")
                            search = msg.text.replace(sep[0] + " ","")
                            url = "https://api.xeonwz.ga/api/image/google?q={}".format(urllib.parse.quote(search))
                            with requests.session() as web:
                                web.headers["User-Agent"] = random.choice(Setmain["userAgent"])
                                r = web.get(url)
                                data = r.text
                                data = json.loads(data)
                                if data["data"] != []:
                                    start = timeit.timeit()
                                    items = data["data"]
                                    path = random.choice(items)
                                    a = items.index(path)
                                    b = len(items)
                                    fino10.sendMessage(msg.to,"「Google Image」\nType : Search Image\nTime taken : %seconds" % (start))
                                    fino10.sendImageWithURL(msg.to, str(path))

                        elif cmd.startswith("search-image: "):
                          if msg._from in admin:
                            sep = msg.text.split(" ")
                            search = msg.text.replace(separate[0] + " ","")
                            with requests.session() as web:
                            	web.headers["User-Agent"] = random.choice(Setmain["userAgent"])
                            r = web.get("http://rahandiapi.herokuapp.com/imageapi?key=betakey&q={}".format(urllib.parse.quote(search)))
                            data = r.text
                            data = json.loads(data)
                            if data["result"] != []:
                            	items = data["result"]
                            path = random.choice(items)
                            a = items.index(path)
                            b = len(items)
                            fino.sendImageWithURL(to, str(path))

                        elif cmd.startswith("search-youtube: "):
                          if msg._from in admin:
                            sep = msg.text.split(" ")
                            params = msg.text.replace(separate[0] + " ","")
                            with requests.session() as web:
                            	web.headers["User-Agent"] = random.choice(Setmain["userAgent"])
                            r = web.get("https://www.youtube.com/results", params = params)
                            soup = BeautifulSoup(r.content, "html5lib")
                            ret_ = "╔══[ Youtube Result ]"
                            datas = []
                            for data in soup.select(".yt-lockup-title > a[title]"):
                            	if "&lists" not in data["href"]:
                            	     datas.append(data)
                            for data in datas:
                            	ret_ += "\n╠══[ {} ]".format(str(data["title"]))
                            ret_ += "\n╠ https://www.youtube.com{}".format(str(data["href"]))
                            ret_ += "\n╚══[ Total {} ]".format(len(datas))
                            fino.sendMessage(to, str(ret_))

                        elif cmd.startswith("ytmp4: "):
                          if msg._from in admin:
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = msg.text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                search_url="https://www.youtube.com/results?search_query="
                                mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                sb_url = search_url + query
                                sb_get = requests.get(sb_url, headers = mozhdr)
                                soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                x = (yt_links[1])
                                yt_href =  x.get("href")
                                yt_href = yt_href.replace("watch?v=", "")
                                qx = "https://youtu.be" + str(yt_href)
                                vid = pafy.new(qx)
                                stream = vid.streams
                                best = vid.getbest()
                                best.resolution, best.extension
                                for s in stream:
                                    me = best.url
                                    hasil = ""
                                    title = "Judul [ " + vid.title + " ]"
                                    author = '\n\n♐ Author : ' + str(vid.author)
                                    durasi = '\n♐ Duration : ' + str(vid.duration)
                                    suka = '\n♐ Likes : ' + str(vid.likes)
                                    rating = '\n♐ Rating : ' + str(vid.rating)
                                    deskripsi = '\n♐ Deskripsi : ' + str(vid.description)
                                fino10.sendVideoWithURL(msg.to, me)
                                fino10.sendMessage(msg.to,title+ author+ durasi+ suka+ rating+ deskripsi)
                            except Exception as e:
                                fino10.sendMessage(msg.to,str(e))

                        elif cmd.startswith("ytmp3: "):
                          if msg._from in admin:
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = msg.text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                search_url="https://www.youtube.com/results?search_query="
                                mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                sb_url = search_url + query
                                sb_get = requests.get(sb_url, headers = mozhdr)
                                soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                x = (yt_links[1])
                                yt_href =  x.get("href")
                                yt_href = yt_href.replace("watch?v=", "")
                                qx = "https://youtu.be" + str(yt_href)
                                vid = pafy.new(qx)
                                stream = vid.streams
                                bestaudio = vid.getbestaudio()
                                bestaudio.bitrate
                                best = vid.getbest()
                                best.resolution, best.extension
                                for s in stream:
                                    shi = bestaudio.url
                                    me = best.url
                                    vin = s.url
                                    hasil = ""
                                    title = "Judul [ " + vid.title + " ]"
                                    author = '\n\n♐ Author : ' + str(vid.author)
                                    durasi = '\n♐ Duration : ' + str(vid.duration)
                                    suka = '\n♐ Likes : ' + str(vid.likes)
                                    rating = '\n♐ Rating : ' + str(vid.rating)
                                    deskripsi = '\n♐ Deskripsi : ' + str(vid.description)
                                fino10.sendImageWithURL(msg.to, me)
                                fino10.sendAudioWithURL(msg.to, shi)
                                fino10.sendMessage(msg.to,title+ author+ durasi+ suka+ rating+ deskripsi)
                            except Exception as e:
                                fino10.sendMessage(msg.to,str(e))

                        elif cmd.startswith("ig: "):
                          if msg._from in admin:
                            try:
                                sep = msg.text.split(" ")
                                instagram = msg.text.replace(sep[0] + " ","")
                                response = requests.get("https://www.instagram.com/"+instagram+"?__a=1")
                                data = response.json()
                                namaIG = str(data['user']['full_name'])
                                bioIG = str(data['user']['biography'])
                                mediaIG = str(data['user']['media']['count'])
                                verifIG = str(data['user']['is_verified'])
                                usernameIG = str(data['user']['username'])
                                followerIG = str(data['user']['followed_by']['count'])
                                profileIG = data['user']['profile_pic_url_hd']
                                privateIG = str(data['user']['is_private'])
                                followIG = str(data['user']['follows']['count'])
                                link = "♐ Link : " + "https://www.instagram.com/" + instagram
                                text = "♐ Name : "+namaIG+"\n♐ Username : "+usernameIG+"\n♐ Biography : "+bioIG+"\n♐ Follower : "+followerIG+"\n♐ Following : "+followIG+"\n♐ Post : "+mediaIG+"\n♐ Verified : "+verifIG+"\n♐ Private : "+privateIG+"" "\n" + link
                                fino10.sendImageWithURL(msg.to, profileIG)
                                fino10.sendMessage(msg.to, str(text))
                            except Exception as e:
                                    fino10.sendMessage(msg.to, str(e))

                        elif cmd.startswith("checkdate: "):
                          if msg._from in admin:
                            sep = msg.text.split(" ")
                            tanggal = msg.text.replace(sep[0] + " ","")
                            r=requests.get('https://script.google.com/macros/exec?service=AKfycbw7gKzP-WYV2F5mc9RaR7yE3Ve1yN91Tjs91hp_jHSE02dSv9w&nama=ervan&tanggal='+tanggal)
                            data=r.text
                            data=json.loads(data)
                            lahir = data["data"]["lahir"]
                            usia = data["data"]["usia"]
                            ultah = data["data"]["ultah"]
                            zodiak = data["data"]["zodiak"]
                            fino10.sendMessage(msg.to,"♐ I N F O R M A T I O N♐\n\n"+"♐ Date Of Birth : "+lahir+"\n♐ Age : "+usia+"\n♐ Date of birth : "+ultah+"\n♐ Zodiak : "+zodiak)
                       
                        elif cmd.startswith("time"):
                          if msg._from in admin:
                          	timeNow = datetime.now()
                          timeHours = datetime.strftime(timeNow,"(%H:%M)")
                          day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                          hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                          bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                          inihari = datetime.today()
                          hr = inihari.strftime('%A')
                          bln = inihari.strftime('%m')
                          for i in range(len(day)):
                          	if hr == day[i]: hasil = hari[i]
                          for k in range(0, len(bulan)):
                          	if bln == str(k): bln = bulan[k-1]
                          rst = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + "\nJam : [ " + inihari.strftime('%H:%M:%S') + " ]"
                          fino10.sendMessage(msg.to, rst)

                        elif cmd.startswith("jumlah: "):
                          if wait["finbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                Disc["limit"] = num
                                fino10.sendMessage(msg.to,"Total Spamtag switch to " +strnum)
                        elif cmd.startswith("spamcall: "):
                          if wait["finbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                Disc["limit"] = num
                                fino10.sendMessage(msg.to,"Total Spamcall switch to " +strnum)
                        elif cmd.startswith("spamtag "):
                          if wait["finbot"] == True:
                           if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(Disc["limit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                fino10.sendMessage(msg)
                                            except Exception as e:
                                                fino10.sendMessage(msg.to,str(e))
                                    else:
                                        fino10.sendMessage(msg.to,"Limit for 1000")
                        elif cmd.startswith("panggil "):
                          if wait["finbot"] == True:
                           if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(Disc["limit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                fino.sendMessage(msg)
                                            except Exception as e:
                                                fino.sendMessage(msg.to,str(e))
                                    else:
                                        fino.sendMessage(msg.to,"Limit for 1000")
                                        
                        elif cmd == "naik":
                          if wait["finbot"] == True:
                           if msg._from in admin:
                             if msg.toType == 2:
                                group = fino.getGroup(msg.to)
                                members = [mem.mid for mem in group.members]
                                jmlh = int(Disc["limit"])
                                fino.sendMessage(msg.to, "Reissue call granted {} Reissued Call Grup".format(str(Disc["limit"])))
                                if jmlh <= 1000:
                                  for x in range(jmlh):
                                     try:
                                        fino.acquireGroupCallRoute(msg.to)
                                        fino.inviteIntoGroupCall(msg.to, contactIds=members)
                                     except Exception as e:
                                        fino.sendMessage(msg.to,str(e))
                                else:
                                    fino.sendMessage(msg.to,"Limited list")
                                    
                        elif 'Gift: ' in msg.text:
                          if wait["finbot"] == True:
                           if msg._from in admin:
                              korban = msg.text.replace('Gift: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      fino10.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)
                                      fino1.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)
                                      fino2.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)
                                      fino3.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)
                        elif 'Spam: ' in msg.text:
                          if wait["finbot"] == True:
                           if msg._from in admin:
                              korban = msg.text.replace('Spam: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      fino10.sendMessage(midd, str(Disc["message2"]))
                                      fino1.sendMessage(midd, str(Disc["message2"]))
                                      fino2.sendMessage(midd, str(Disc["message2"]))
                                      fino3.sendMessage(midd, str(Disc["message2"]))
                                      fino4.sendMessage(midd, str(Disc["message2"]))
                                      fino5.sendMessage(midd, str(Disc["message2"]))
                                      fino6.sendMessage(midd, str(Disc["message2"]))
                                      fino7.sendMessage(midd, str(Disc["message2"]))
                                      fino8.sendMessage(midd, str(Disc["message2"]))
                                      fino9.sendMessage(midd, str(Disc["message2"]))
                        elif 'get-idline: ' in msg.text:
                          if wait["finbot"] == True:
                           if msg._from in admin:
                              msgs = msg.text.replace('.get-idline: ','')
                              conn = fino.findContactsByUserid(msgs)
                              if True:
                                  fino.sendMessage(msg.to, "http://line.me/ti/p/~" + msgs)
                                  fino.sendMessage(msg.to, None, contentMetadata={'mid': conn.mid}, contentType=13)

#===========Protection============#
                        elif 'Welcome ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = "Welcome Msg sudah aktif"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = fino.getGroup(msg.to)
                                       msgs = "Welcome Msg Enable\nDi Group : " +str(ginfo.name)
                                  fino10.sendMessage(msg.to, "「Enable」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = fino.getGroup(msg.to)
                                         msgs = "Welcome Msg Disable\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Welcome Msg sudah tidak aktif"
                                    fino10.sendMessage(msg.to, "「Disable」\n" + msgs)
                        elif 'ProQr ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Proqr ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = "Protect qr sudah aktif"
                                  else:
                                       protectqr.append(msg.to)
                                       ginfo = fino.getGroup(msg.to)
                                       msgs = "Protect qr Enable\nDi Group : " +str(ginfo.name)
                                  fino10.sendMessage(msg.to, "「Enable」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                         ginfo = fino.getGroup(msg.to)
                                         msgs = "Protect qr Disable\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect qr sudah tidak aktif"
                                    fino10.sendMessage(msg.to, "「Disable」\n" + msgs)
                        elif 'Promem ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Promember ','')
                              if spl == 'on':
                                  if msg.to in protectkick:
                                       msgs = "Protect member sudah aktif"
                                  else:
                                       protectkick.append(msg.to)
                                       ginfo = fino.getGroup(msg.to)
                                       msgs = "Protect member Enable\nDi Group : " +str(ginfo.name)
                                  fino10.sendMessage(msg.to, "「Enable」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                         ginfo = fino.getGroup(msg.to)
                                         msgs = "Protect member Disable\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect member sudah tidak aktif"
                                    fino10.sendMessage(msg.to, "「Disable」\n" + msgs)
                        elif 'ProJoin ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Projoin ','')
                              if spl == 'on':
                                  if msg.to in protectjoin:
                                       msgs = "Protect join turn on"
                                  else:
                                       protectjoin.append(msg.to)
                                       ginfo = fino.getGroup(msg.to)
                                       msgs = "Protect join Enable\nDi Group : " +str(ginfo.name)
                                  fino10.sendMessage(msg.to, "「Enable」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                         ginfo = fino.getGroup(msg.to)
                                         msgs = "Protect join Disable\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect join turn off"
                                    fino10.sendMessage(msg.to, "「Disable」\n" + msgs)
                        elif 'finbot ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('finbot ','')
                              if spl == 'on':
                                  if msg.to in protectinvite:
                                       msgs = "finbot ready"
                                  else:
                                       protectinvite.append(msg.to)
                                       ginfo = fino.getGroup(msg.to)
                                       msgs = "finbot ready " +str(ginfo.name)
                                  fino10.sendMessage(msg.to, "finbot ready\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                         ginfo = fino.getGroup(msg.to)
                                         msgs = "finbot stand" +str(ginfo.name)
                                    else:
                                         msgs = "stand"
                                    fino10.sendMessage(msg.to, "stand at\n" + msgs)
                        elif 'Procancel ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Procancel ','')
                              if spl == 'on':
                                  if msg.to in protectcancel:
                                       msgs = "احسن"
                                  else:
                                       protectcancel.append(msg.to)
                                       ginfo = fino.getGroup(msg.to)
                                       msgs = "احسن\nفی : " +str(ginfo.name)
                                  fino10.sendMessage(msg.to, "「Enable」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = fino.getGroup(msg.to)
                                         msgs = "احسن\nفی : " +str(ginfo.name)
                                    else:
                                         msgs = "الا احن فی"
                                    fino10.sendMessage(msg.to, "「Disable」\n" + msgs)
                        elif 'Protectall ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectall ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = ""
                                  else:
                                       protectqr.append(msg.to)
                                  if msg.to in protectkick:
                                      msgs = ""
                                  else:
                                      protectkick.append(msg.to)
                                  if msg.to in protectjoin:
                                      msgs = ""
                                  else:
                                      protectjoin.append(msg.to)
                                  if msg.to in protectcancel:
                                      ginfo = fino.getGroup(msg.to)
                                      msgs = "All protection on\nAt Group : " +str(ginfo.name)
                                  else:
                                      protectcancel.append(msg.to)
                                      ginfo = fino.getGroup(msg.to)
                                      msgs = "All protect on\nAt Group : " +str(ginfo.name)
                                  fino10.sendMessage(msg.to, "「Enable」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = fino.getGroup(msg.to)
                                         msgs = "All protection off\nAt Group : " +str(ginfo.name)
                                    else:
                                         ginfo = fino.getGroup(msg.to)
                                         msgs = "All protect off\nAt Group : " +str(ginfo.name)
                                    fino10.sendMessage(msg.to, "「Disable」\n" + msgs)
#===========KICKOUT============#
                        elif ("Nk " in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           G = fino10.getGroup(msg.to)
                                           G.preventedJoinByTicket = False
                                           fino10.updateGroup(G)
                                           invsend = 0
                                           Ticket = fino10.reissueGroupTicket(msg.to)
                                           sw1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                           sw1.kickoutFromGroup(msg.to, [target])
                                           sw1.leaveGroup(msg.to)
                                           X = fino10.getGroup(msg.to)
                                           X.preventedJoinByTicket = True
                                           fino10.updateGroup(X)
                                       except:
                                           pass

                        elif ("Dum " in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           random.choice(KAC).kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass
        
#Sett command
                        elif cmd == "Read on" or text.lower() == 'read on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Setmain["AutoRead"] = True
                                fino10.sendMessage(msg.to,"Read Enable")
                        elif cmd == "Read off" or text.lower() == 'read off':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Setmain["AutoRead"] = False
                                fino10.sendMessage(msg.to,"Read Dissable")
                        elif cmd == "tagkick on" or text.lower() == 'notag on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["Mentionkick"] = True
                                fino10.sendMessage(msg.to,"Tagkick Enable")
                        elif cmd == "tagkick off" or text.lower() == 'notag off':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["MentionKick"] = False
                                fino10.sendMessage(msg.to,"Tagkick Disable")
                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["contact"] = True
                                fino10.sendMessage(msg.to,"Contact Detect Enable")
                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["contact"] = False
                                fino10.sendMessage(msg.to,"Contact Detect Disable")
                        elif cmd == "respon on" or text.lower() == 'respon on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["detectMention"] = True
                                fino10.sendMessage(msg.to,"Auto respon Enable")
                        elif cmd == "respon off" or text.lower() == 'respon off':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["detectMention"] = False
                                fino10.sendMessage(msg.to,"Auto respon Disable")
                        elif cmd == "respon1 on" or text.lower() == 'respon1 on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                wait["detectMention1"] = True
                                fino10.sendMessage(msg.to,"Auto respon1 Enable")
                        elif cmd == "respon1 off" or text.lower() == 'respon1 off':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                wait["detectMention1"] = False
                                fino10.sendMessage(msg.to,"Auto respon1 Disable")
                        elif cmd == "autojoin on" or text.lower() == 'autojoin on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["autoJoin"] = True
                                fino10.sendMessage(msg.to,"Autojoin Enable")
                        elif cmd == "autojoin off" or text.lower() == 'autojoin off':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["autoJoin"] = False
                                fino10.sendMessage(msg.to,"Autojoin Disable")
                        elif cmd == "autoleave on" or text.lower() == 'autoleave on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["autoLeave"] = True
                                fino10.sendMessage(msg.to,"Autoleave Enable")
                        elif cmd == "autoleave off" or text.lower() == 'autoleave off':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["autoLeave"] = False
                                fino10.sendMessage(msg.to,"Autoleave Disable")
                        elif cmd == "autoadd on" or text.lower() == 'autoadd on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["autoAdd"] = True
                                fino10.sendMessage(msg.to,"Auto add Enable")
                        elif cmd == "autoadd off" or text.lower() == 'autoadd off':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["autoAdd"] = False
                                fino10.sendMessage(msg.to,"Auto add Disable")
                        elif cmd == "sticker on" or text.lower() == 'sticker on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["sticker"] = True
                                fino10.sendMessage(msg.to,"Deteksi sticker Enable")
                        elif cmd == "sticker off" or text.lower() == 'sticker off':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["sticker"] = False
                                fino10.sendMessage(msg.to,"Deteksi sticker Disable")
                        elif cmd == "spyer on" or text.lower() == 'spyer on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["spyer"] = True
                                fino10.sendMessage(msg.to,"Detect for spy on")
                        elif cmd == "spyer off" or text.lower() == 'spyer off':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["spyer"] = False
                                fino10.sendMessage(msg.to,"Detect for spy off")
                        elif cmd == "jointicket on" or text.lower() == 'jointicket on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Setmain["autoJoinTicket"] = True
                                fino10.sendMessage(msg.to,"Join Ticket Enable")
                        elif cmd == "jointicket off" or text.lower() == 'jointicket off':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Setmain["autoJoinTicket"] = False
                                fino10.sendMessage(msg.to,"Join Ticket Disable")
                        elif cmd == "ukir on" or text.lower() == 'ukir on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Setmain["unsendMessage"] = True
                                fino10.sendMessage(msg.to,"Unsend Message Enable")
                        elif cmd == "ukir off" or text.lower() == 'ukir off':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Setmain["unsendMessage"] = False
                                fino10.sendMessage(msg.to,"Unsend Message Disable")

#ADD STAFF \ ADD ADMIN \STAFFLIST\ADMINLIST
                        elif ("admin add " in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admsa["admin"][target] = True
                                           with open('admin.json', 'w') as fp:
                                           	json.dump(admsa, fp, sort_keys=True, indent=4)
                                           fino10.sendMessage(msg.to,"Admin added")
                                       except:
                                           pass
                        elif ("admin del " in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del admsa["admin"][target]
                                           with open('admin.json', 'w') as fp:
                                           	json.dump(admsa, fp, sort_keys=True, indent=4)
                                           fino10.sendMessage(msg.to,"Admin delleted")
                                       except:
                                           pass
                        elif cmd == "adminlist" or text.lower() == 'adminlist':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                              if admsa["admin"] == {}:
                                fino10.sendMessage(msg.to,"No admin added")
                              else:
                                ma = ""
                                a = 0
                                for m_id in admsa["admin"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +fino.getContact(m_id).displayName + "\n"
                                fino10.sendMessage(msg.to,"♐ || Adminlist\n\n"+ma+"\nTotal「%s」Admin User" %(str(len(admsa["admin"]))))
                        elif ("staff add " in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           staff["staff"][target] = True
                                           with open('staff.json', 'w') as fp:
                                           	json.dump(staff, fp, sort_keys=True, indent=4)
                                           fino10.sendMessage(msg.to,"Staff added")
                                       except:
                                           pass
                        elif ("staff del " in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del staff["staff"][target]
                                           with open('staff.json', 'w') as fp:
                                           	json.dump(staff, fp, sort_keys=True, indent=4)
                                           fino10.sendMessage(msg.to,"Staff delleted")
                                       except:
                                           pass
                        elif cmd == "stafflist" or text.lower() == 'stafflist':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                              if staff["staff"] == {}:
                                fino10.sendMessage(msg.to,"No staff added")
                              else:
                                ma = ""
                                a = 0
                                for m_id in staff["staff"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +fino.getContact(m_id).displayName + "\n"
                                fino10.sendMessage(msg.to,"♐ || Stafflist\n\n"+ma+"\nTotal「%s」Staff User" %(str(len(staff["staff"]))))
                                
#Ban\talkban\bannlist\talklist
                        elif cmd == "friend add:on" or text.lower() == 'friend:on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["Talkwblacklist"] = True
                                fino10.sendMessage(msg.to,"Please send contact...")
                        elif cmd == "friend dell:on" or text.lower() == 'temen:on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["Talkdblacklist"] = True
                                fino10.sendMessage(msg.to,"Please send contact...")
                        elif cmd == "talkban add" or text.lower() == 'friend:on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["Talkwblacklist"] = True
                                fino10.sendMessage(msg.to,"Please send contact...")
                        elif cmd == "talkban del" or text.lower() == 'talkban dell:on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["Talkdblacklist"] = True
                                fino10.sendMessage(msg.to,"Please send contact...")
                        elif ("Temenadd " in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           Disc["Talkblacklist"][target] = True
                                           with open('prevent.json', 'w') as fp:
                                           	json.dump(staff, fp, sort_keys=True, indent=4)
                                           fino10.sendMessage(msg.to,"Friend added")
                                       except:
                                           pass
                        elif ("Temendell " in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del Disc["Talkblacklist"][target]
                                           with open('prevent.json', 'w') as fp:
                                           	json.dump(staff, fp, sort_keys=True, indent=4)
                                           fino10.sendMessage(msg.to,"Friend deleted")
                                       except:
                                           pass
                        elif ("Talkban:add " in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           Disc["Talkblacklist"][target] = True
                                           with open('prevent.json', 'w') as fp:
                                           	json.dump(staff, fp, sort_keys=True, indent=4)
                                           fino10.sendMessage(msg.to,"Talklist added")
                                       except:
                                           pass
                        elif ("Talkban:dell " in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del Disc["Talkblacklist"][target]
                                           with open('prevent.json', 'w') as fp:
                                           	json.dump(staff, fp, sort_keys=True, indent=4)
                                           fino10.sendMessage(msg.to,"Talklist deleted")
                                       except:
                                           pass
                        elif cmd == "talkbanlist" or text.lower() == 'talkbanlist':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                              if Disc["Talkblacklist"] == {}:
                                fino10.sendMessage(msg.to,"No Talkban user")
                              else:
                                ma = ""
                                a = 0
                                for m_id in Disc["Talkblacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +fino.getContact(m_id).displayName + "\n"
                                fino10.sendMessage(msg.to,"♐ |SB| Talkban User\n\n"+ma+"\nTotal「%s」Talkban User" %(str(len(Disc["Talkblacklist"]))))

#Banned
                        elif ("Ban " in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           Disc["blacklist"][target] = True
                                           fino10.sendMessage(msg.to,"Blacklist added")
                                       except:
                                           pass
                        elif ("Unban " in msg.text):
                          if wait["finbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del Disc["blacklist"][target]
                                           fino10.sendMessage(msg.to,"Blacklist deleted")
                                       except:
                                           pass
                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["wblacklist"] = True
                                fino10.sendMessage(msg.to,"Please send contact...")
                        elif cmd == "unban:on" or text.lower() == 'unban:on':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                                Disc["dblacklist"] = True
                                fino10.sendMessage(msg.to,"Please send contact...")
                        elif cmd == "banlist" or text.lower() == 'banlist':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                              if Disc["blacklist"] == {}:
                                fino10.sendMessage(msg.to,"No blacklist")
                              else:
                                ma = ""
                                a = 0
                                for m_id in Disc["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + "│ " +fino.getContact(m_id).displayName + "\n"
                                fino10.sendMessage(msg.to,"╭─「 List Banned 」─\n"+ma+"\n╰──────────\nTotal「%s」Blacklist User" %(str(len(Disc["blacklist"]))))
                        elif cmd == "blc" or text.lower() == 'blc':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                              if Disc["blacklist"] == {}:
                                    fino10.sendMessage(msg.to,"No blacklist")
                              else:
                                    ma = ""
                                    for i in Disc["blacklist"]:
                                        ma = fino.getContact(i)
                                        fino10.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                        elif cmd == "clearban" or text.lower() == 'clearban':
                          if wait["finbot"] == True:
                            if msg._from in admin:
                              Disc["blacklist"] = {}
                              ragets = fino.getContacts(Disc["blacklist"])
                              mc = "「%i」User Blacklist" % len(ragets)
                              fino10.sendMessage(msg.to,"Banned list deleted " +mc)

#Setting message\spamming command
                        elif 'Set pesan: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set pesan: ','')
                              if spl in [""," ","\n",None]:
                                  fino10.sendMessage(msg.to, "Failed to sett priv Msg")
                              else:
                                  Disc["message"] = spl
                                  fino10.sendMessage(msg.to, "「Pesan Msg」\nPriv Msg switch to :\n\n「{}」".format(str(spl)))
                        elif 'Set welcome: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set welcome: ','')
                              if spl in [""," ","\n",None]:
                                  fino10.sendMessage(msg.to, "Welcome Msg sett failure... ")
                              else:
                                  Disc["welcome"] = spl
                                  fino10.sendMessage(msg.to, "「Welcome Msg」\nWelcome Msg Switch to :\n\n「{}」".format(str(spl)))
                        elif 'Set respon: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon: ','')
                              if spl in [""," ","\n",None]:
                                  fino10.sendMessage(msg.to, "Respon Msg sett failure")
                              else:
                                  Disc["Respontag"] = spl
                                  fino10.sendMessage(msg.to, "「Respon Msg」\nRespon Msg switch to :\n\n「{}」".format(str(spl)))
                        elif 'Set respon1: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon1: ','')
                              if spl in [""," ","\n",None]:
                                  fino10.sendMessage(msg.to, "Respon Msg sett failure")
                              else:
                                  Disc["Respontag1"] = spl
                                  fino10.sendMessage(msg.to, "「Respon Msg」\nRespon Msg switch to :\n\n「{}」".format(str(spl)))
                        elif 'Set spam: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set spam: ','')
                              if spl in [""," ","\n",None]:
                                  fino10.sendMessage(msg.to, "Sett Spam limitation failure... ")
                              else:
                                  Disc["message2"] = spl
                                  fino10.sendMessage(msg.to, "「Spam Msg」\nSpam Msg switch to :\n\n「{}」".format(str(spl)))
                        elif 'Set sider: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set sider: ','')
                              if spl in [""," ","\n",None]:
                                  fino10.sendMessage(msg.to, "Failure Set to Sider Msg")
                              else:
                                  Disc["mention"] = spl
                                  fino10.sendMessage(msg.to, "「Sider Msg」\nSider Msg changed to :\n\n「{}」".format(str(spl)))
                        elif text.lower() == "cek pesan":
                            if msg._from in admin:
                               fino10.sendMessage(msg.to, "「Priv Msg」\nYour Msg is :\n\n「 " + str(Disc["message"]) + " 」")
                        elif text.lower() == "cek welcome":
                            if msg._from in admin:
                               fino10.sendMessage(msg.to, "「Welcome Msg」\nYour Welcome Msg is :\n\n「 " + str(Disc["welcome"]) + " 」")
                        elif text.lower() == "cek respon":
                            if msg._from in admin:
                               fino10.sendMessage(msg.to, "「Respon Msg」\nYour Respon Msg is :\n\n「 " + str(Disc["Respontag"]) + " 」")
                        elif text.lower() == "cek respon1":
                            if msg._from in admin:
                               fino10.sendMessage(msg.to, "「Respon Msg」\nYour Respon Msg is :\n\n「 " + str(Disc["Respontag1"]) + " 」")
                        elif text.lower() == "cek spam":
                            if msg._from in admin:
                               fino10.sendMessage(msg.to, "「Spam Msg」\nYour Spam Msg is :\n\n「 " + str(Disc["message2"]) + " 」")
                        elif text.lower() == "cek sider":
                            if msg._from in admin:
                               fino10.sendMessage(msg.to, "「Sider Msg」\nYour Sider Msg is :\n\n「 " + str(Disc["mention"]) + " 」")

#Auto join by ticket id============#
                        elif "/ti/g/" in msg.text.lower():
                          if wait["finbot"] == True:
                            if msg._from in admin:
                              if Setmain["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = fino.findGroupByTicket(ticket_id)
                                     fino.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     fino.sendMessage(msg.to, "in : %s" % str(group.name))
                                     group1 = fino1.findGroupByTicket(ticket_id)
                                     fino1.acceptGroupInvitationByTicket(group1.id,ticket_id)
                                     fino1.sendMessage(msg.to, "in : %s" % str(group.name))
                                     group2 = fino2.findGroupByTicket(ticket_id)
                                     fino2.acceptGroupInvitationByTicket(group2.id,ticket_id)
                                     fino2.sendMessage(msg.to, "in : %s" % str(group.name))
                                     group3 = fino3.findGroupByTicket(ticket_id)
                                     fino3.acceptGroupInvitationByTicket(group3.id,ticket_id)
                                     fino3.sendMessage(msg.to, "in : %s" % str(group.name))

        if op.type == 55:
            try:
                if op.param1 in Setmain["readPoint"]:
                   if op.param2 in Setmain["readMember"][op.param1]:
                       pass
                   else:
                       Setmain["readMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass

        if op.type == 55:
            if op.param2 in Disc["blacklist"]:
                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = fino.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])

    except Exception as error:
        print (error) 
        
while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                bot(op)
                oepoll.setRevision(op.revision)
    except Exception as e:
        print (e)
